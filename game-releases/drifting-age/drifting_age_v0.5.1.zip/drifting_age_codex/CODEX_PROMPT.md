请先读取仓库中的 `AGENTS.md`、`CODEX_TASK.md`、`CONVERSATION_HISTORY.md`、`README.md` 和 `QA_REPORT.md`，然后直接在当前项目中继续开发，不要只给建议或伪代码。

首要任务是修复 CODEX_TASK.md 中的两个 P0 问题：玩家落水后无法重新登上木筏/岛屿；水中未按 Space 时要逐渐下沉，按住 Space 时要逐渐上浮至水面。请先复现并解释根因，再实现显式水中状态机、木筏边缘上岸交互和岛屿海滩登陆。保持 3×3 初始木筏、单人模式、最多两人联机和现有 3D WebGL 客户端。

请实际运行代码和验收测试；视觉验收必须在真实支持 WebGL 的浏览器中进行。不要把 no-op WebGL mock 的测试当作 3D 渲染通过。完成后更新 README.md 与 QA_REPORT.md，列出每项测试的真实结果、截图和未解决问题。
