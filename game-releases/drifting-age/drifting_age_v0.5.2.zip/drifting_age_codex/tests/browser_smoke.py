"""Real Chromium/WebGL integration. Requires Python Playwright and system Chromium.
Run python3 tests/browser_smoke.py from the project root. Starts an isolated server;
set TEST_BASE only to use a dedicated existing server instead.
Only the test-served HTML receives a closure hook; production exposes no test API.
"""
from pathlib import Path
import json, re, os, socket, subprocess, atexit, time
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
BASE=os.environ.get('TEST_BASE')
if not BASE:
 with socket.socket() as probe:
  probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
 server=subprocess.Popen(['node','server.js'],env={**os.environ,'PORT':str(port)},stdout=subprocess.DEVNULL)
 def cleanup():
  if server.poll() is None:server.terminate();server.wait(timeout=5)
 atexit.register(cleanup)
 BASE=f'http://127.0.0.1:{port}'
 for _ in range(100):
  try:
   with urlopen(BASE) as response:assert response.status==200
   break
  except OSError:time.sleep(.05)
 else:raise RuntimeError('Isolated test server failed to start')
ART=Path('docs/artifacts');ART.mkdir(parents=True,exist_ok=True)
SOURCE=Path('public/index.html').read_text()
HOOK='''let qaPaused=false,qaRenderPaused=false;window.qa={
 renderPause(){qaRenderPaused=true;},
 get(){return {me:JSON.parse(JSON.stringify(me)),state:JSON.parse(JSON.stringify(state)),selected:preselected?.resource.id,view:currentView(),webgl:!!gl&&!!program,glError:gl&&gl.getError(),renderError,camYaw,bindings:{...bindings}};},
 fresh(){qaPaused=true;mode='solo';gameStarted=true;state=freshState();me=freshPlayer();me.x=500;state.players=[me];OceanMovement.normalize(state,me);OceanItems.slots(me);input={};camYaw=0;camPitch=.42;camDist=9.2;syncHUD();},
 set(p){Object.assign(me,p);delete me.motion;delete me.boarding;OceanMovement.normalize(state,me);syncHUD();},
 full(){me.inventory={plank:20,plastic:20,leaf:20,scrap:20,stone:1,food:1,water:1};me.tools={hook:1,spear:1,axe:1,rod:1};me.hotbar=[...OceanItems.defaults];me.selectedSlot=4;syncHUD();},
 resources(r){state.resources=r;},
 tick(keys,seconds){input={...keys};for(let t=0;t<seconds-1e-8;t+=1/60)updateLocal(Math.min(1/60,seconds-t));input={};syncHUD();return JSON.parse(JSON.stringify(me));},
 keys(k){input={...k};sendInputs();},view(yaw,pitch=.42){camYaw=yaw;camPitch=pitch;},
 act(a,d){return localAction(a,d||{});},send(a,d){sendAction(a,d||{});},save(){saveSolo();},
 aim(id){for(let yaw=-Math.PI;yaw<Math.PI;yaw+=.09)for(let pitch=-1;pitch<1.2;pitch+=.055){const v={yaw,pitch,dist:camDist,aspect:canvas.clientWidth/canvas.clientHeight,upward:false};const t=OceanTargeting.select(state,me,v);if(t&&(!id||t.resource.id===id)){camYaw=yaw;camPitch=pitch;updatePreselection();return t.resource.id;}}return null;},
 request(){return pickupRequest();}
};'''
INSTRUMENTED=SOURCE.replace("if(mode==='solo')updateLocal(dt);","if(mode==='solo'&&!qaPaused)updateLocal(dt);").replace(' if(!state||!me){',' if(qaRenderPaused){requestAnimationFrame(render3D);return;}\n if(!state||!me){',1).replace('})();\n</script>',HOOK+'})();\n</script>')
Path('docs/browser-results-v0.5.2.json').unlink(missing_ok=True)
results={}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
 context=browser.new_context(viewport={'width':1100,'height':720},permissions=['local-network-access'])
 context.route('**/index.html',lambda r:r.fulfill(body=INSTRUMENTED,content_type='text/html'))
 page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'/index.html');page.click('#startBtn');page.wait_for_timeout(300);page.evaluate('qa.fresh()')
 assert page.evaluate('qa.get().webgl')
 # Full-bar craft through the UI after releasing mouse capture.
 page.keyboard.press('Escape');page.evaluate('qa.full()');page.locator('#recipes button').filter(has_text='水瓶').click();page.wait_for_timeout(1200)
 p=page.evaluate('qa.get().me');assert p['hotbar'][p['selectedSlot']]=='bottle' and p['tools']['bottle']==1
 drops=page.evaluate('qa.get().state.resources.filter(r=>r.dropItem)');assert len(drops)==1 and drops[0]['amount']==20 and drops[0]['type']=='plank'
 page.screenshot(path=str(ART/'v0.5.2-crafted-equipped.png'))
 page.mouse.click(550,330);page.wait_for_function('document.pointerLockElement===document.querySelector("#gl")')
 before=page.evaluate('qa.get().camYaw');page.mouse.move(580,330);assert page.evaluate('qa.get().camYaw')!=before
 page.keyboard.press('Escape');page.wait_for_timeout(1200);page.click('#settingsBtn');page.click('#settingsDone');page.click('#cameraBtn');page.wait_for_function('document.pointerLockElement===document.querySelector("#gl")')
 results['mouse_control']='PASS: Escape → craft → canvas click restores pointer lock; settings → continue control restores lock; mouse look works'
 # Drop retrieval uses centre-screen targeting and retains the entire stack.
 drop_id=drops[0]['id'];assert page.evaluate('(id)=>qa.aim(id)',drop_id)==drop_id
 page.keyboard.press('e');assert page.evaluate('qa.get().me.inventory.plank')==20
 results['full_bar_crafting']='PASS: bottle auto-equipped, previous 20 planks dropped and targeted pickup restored all 20'
 # Craftable stations are real held items, explicitly placed on the raft.
 page.keyboard.press('Escape');page.locator('#recipes button').filter(has_text='海水淡化器').click();page.wait_for_timeout(1200)
 assert page.evaluate('qa.get().me.hotbar[qa.get().me.selectedSlot]')=='purifier'
 assert page.evaluate('qa.get().state.stations.purifier')==0
 page.mouse.click(550,330);page.wait_for_function('document.pointerLockElement!==null');assert page.evaluate('qa.get().state.stations.purifier')==0
 page.mouse.click(550,330);assert page.evaluate('qa.get().state.stations.purifier')==1
 results['craft_station']='PASS: station stays held until a separate left click; click-to-resume does not accidentally place'
 # A closer item outside the circle must not steal the pickup.
 page.evaluate('qa.fresh();qa.resources([{id:"aimed",type:"plank",x:526,y:285,altitude:.8},{id:"closer",type:"plastic",x:460,y:340,altitude:.8}])')
 page.wait_for_function('qa.get().selected==="aimed"');assert '木板' in page.locator('#aimLabel').inner_text()
 page.screenshot(path=str(ART/'v0.5.2-aim-highlight.png'))
 old=page.evaluate('qa.get().me.inventory.plank');page.keyboard.press('e');assert page.evaluate('qa.get().me.inventory.plank')==old+2
 assert page.evaluate('qa.get().state.resources.map(r=>r.id)')==['closer']
 page.keyboard.press('e');assert page.evaluate('qa.get().state.resources.length')==1
 page.evaluate('qa.resources([{id:"far",type:"plank",x:500,y:150}])');page.wait_for_timeout(100);assert page.evaluate('qa.get().selected') is None
 results['targeted_pickup']='PASS: centred item outlined/named and picked; closer off-axis item remains; empty-circle and distant pickups do nothing'
 # Seabed targeting uses the same screen-space selection.
 page.evaluate('qa.set({x:420,y:440,altitude:-7.25})');assert page.evaluate('qa.aim("ore_m1")')=='ore_m1'
 page.wait_for_timeout(100);page.screenshot(path=str(ART/'v0.5.2-underwater-target.png'));page.keyboard.press('e');assert page.evaluate('qa.get().me.inventory.metal')==1
 results['underwater_target']='PASS: real WebGL mineral highlight/name and targeted mining'
 # Automatic boarding: no E key, no teleport through the underside.
 page.evaluate('qa.fresh();qa.set({x:575,y:350,altitude:-.34})');p=page.evaluate('qa.tick({left:true,upward:true},1.4)');assert p['motion']=='RAFT_GROUNDED'
 page.screenshot(path=str(ART/'v0.5.2-auto-board.png'))
 page.evaluate('qa.set({x:500,y:350,altitude:-2})');p=page.evaluate('qa.tick({upward:true},3)');assert p['altitude']==-.72 and p['motion']=='UNDERWATER'
 page.evaluate('qa.tick({right:true,upward:true},1.6)');page.evaluate('qa.tick({upward:true},2)');p=page.evaluate('qa.tick({left:true,upward:true},2)');assert p['motion']=='RAFT_GROUNDED'
 results['auto_boarding']='PASS: surface approach automatically boards; underside blocks ascent; swimming out allows boarding'
 page.keyboard.press('0');assert page.evaluate('qa.get().me.selectedSlot')==9
 page.keyboard.press('ArrowRight');assert page.evaluate('qa.get().me.selectedSlot')==0
 page.evaluate('qa.save()');assert page.evaluate('JSON.parse(localStorage.getItem("driftingAge3dSave")).players[0].hotbar.length')==10
 assert page.evaluate('qa.get().glError')==0;assert not errors,errors
 print('Single-player browser checks passed',flush=True);context.close()
 # Real two-player protocol; no server position injection.
 online=browser.new_context(viewport={'width':800,'height':600},permissions=['local-network-access'])
 online.route('**/index.html',lambda r:r.fulfill(body=INSTRUMENTED,content_type='text/html'))
 clients=[]
 for i in range(2):
  c=online.new_page();clients.append(c);c.on('pageerror',lambda e:errors.append(str(e)));c.goto(BASE+'/index.html');c.locator('[data-mode="coop"]').click();c.click('#startBtn');c.wait_for_function('qa.get().me!==null',polling=100);c.evaluate('qa.view(0);qa.renderPause()')
 a,b=clients;a.wait_for_function('qa.get().state.players.length===2',polling=100)
 a.evaluate('document.exitPointerLock()');a.locator('#recipes button').filter(has_text='水瓶').click();a.wait_for_function('qa.get().me.tools.bottle===1',polling=100)
 assert a.evaluate('qa.get().me.hotbar[qa.get().me.selectedSlot]')=='bottle'
 aid=a.evaluate('qa.get().me.id');b.wait_for_function('(id)=>qa.get().state.players.find(p=>p.id===id)?.tools.bottle===1',arg=aid,polling=100)
 a.keyboard.press('5');a.wait_for_function('qa.get().me.selectedSlot===4',polling=100);a.wait_for_timeout(300);assert a.evaluate('qa.get().me.selectedSlot')==4
 a.evaluate('qa.send("pickup",{targetId:"fabricated",view:qa.get().view})');a.wait_for_timeout(150);assert a.evaluate('qa.get().me.inventory.plank')==8
 # Move up the raft to within reach of the world debris and select through the actual camera.
 a.evaluate('qa.keys({up:true})');a.wait_for_function('qa.get().me.y<305',polling=50);a.evaluate('qa.keys({})')
 target=a.evaluate('qa.aim()');assert target is not None
 req=a.evaluate('qa.request()');a.evaluate('(d)=>qa.send("pickup",d)',req)
 a.wait_for_function('(id)=>!qa.get().state.resources.some(r=>r.id===id)',arg=target,polling=100)
 b.wait_for_function('(id)=>!qa.get().state.resources.some(r=>r.id===id)',arg=target,polling=100)
 # Duplicate request from the observer must not materialise a second copy.
 before=b.evaluate('qa.get().me.inventory');b.evaluate('(d)=>qa.send("pickup",d)',req);b.wait_for_timeout(200);assert b.evaluate('qa.get().me.inventory')==before
 results['multiplayer_items']='PASS: craft auto-equips and syncs to observer; selected slot remains stable; exact-target pickup syncs; fabricated and already-collected IDs rejected'
 # Move back to middle row, then leave east edge, surface and swim inward automatically.
 a.evaluate('qa.view(0);qa.keys({down:true})');a.wait_for_function('qa.get().me.y>=348',polling=50);a.evaluate('qa.keys({right:true})');a.wait_for_function('qa.get().me.x>580',polling=50);a.evaluate('qa.keys({})');a.wait_for_function('qa.get().me.altitude<-1.2',polling=100)
 a.evaluate('qa.keys({upward:true})');a.wait_for_function('qa.get().me.motion==="SURFACE_SWIM"',polling=100);a.evaluate('qa.keys({left:true,upward:true})');
 try:a.wait_for_function('qa.get().me.motion==="BOARDING"',polling=50,timeout=10000)
 except Exception:
  print('Failed return position',a.evaluate('qa.get().me'),flush=True);raise
 a.evaluate('qa.keys({upward:true})');a.wait_for_function('qa.get().me.motion==="RAFT_GROUNDED"',polling=100)
 b.wait_for_function('(id)=>qa.get().state.players.find(p=>p.id===id)?.motion==="RAFT_GROUNDED"',arg=aid,polling=100)
 results['multiplayer_auto_board']='PASS: no E required; authority and observer both report valid grounded deck state'
 full=a.evaluate('''() => new Promise(resolve=>{const s=new WebSocket(`ws://${location.host}/?name=third`);s.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='full')resolve(m.type);};setTimeout(()=>resolve('timeout'),3000);})''');assert full=='full'
 b.close();a.wait_for_function('qa.get().state.players.length===1',polling=100)
 results['capacity_disconnect']='PASS: two-player limit and disconnect cleanup'
 assert not errors,errors
 results['webgl']='PASS: real WebGL, no page exceptions, GL_NO_ERROR; scene/highlight/underwater/boarding screenshots saved'
 browser.close()
Path('docs/browser-results-v0.5.2.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
