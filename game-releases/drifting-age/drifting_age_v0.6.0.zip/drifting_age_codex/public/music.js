/* Three original offline-ready miniatures. No borrowed melodies or audio assets. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.OceanMusic=factory();})(globalThis,function(){
 'use strict';
 const tracks=[
  {title:'晨光轻舟',bpm:84,bars:16,instrument:'pluck',transpose:0,
   melody:[[72,null,76,79,76,74,72,null],[74,76,77,null,76,74,72,null],[69,null,72,76,79,76,72,69],[71,74,79,null,77,74,71,null],
    [72,76,79,84,79,null,76,72],[77,null,81,79,77,76,74,null],[76,79,81,null,79,76,72,69],[74,71,67,null,71,74,79,null],
    [79,null,76,72,74,76,79,null],[81,79,77,null,76,77,81,null],[81,null,79,76,72,76,79,76],[74,77,79,null,77,74,71,null],
    [72,74,76,79,84,null,79,76],[77,76,74,null,72,74,77,null],[76,null,72,69,72,76,74,72],[71,74,72,null,72,null,null,null]]},
  {title:'午后海风',bpm:100,bars:16,instrument:'marimba',transpose:5,
   melody:[[72,76,null,79,76,null,74,72],[77,null,76,74,72,74,77,null],[76,79,null,81,79,76,72,null],[74,null,71,67,71,74,79,null],
    [79,76,72,null,76,79,84,null],[81,77,74,null,77,81,79,null],[81,null,79,76,72,76,79,null],[77,74,71,null,74,79,77,null],
    [76,72,76,79,null,84,79,76],[77,74,77,81,null,79,77,74],[76,72,69,null,72,76,79,81],[79,77,74,null,71,74,77,null],
    [79,null,76,72,74,76,79,null],[77,81,79,77,76,74,72,null],[76,72,69,null,72,76,74,null],[71,74,72,null,null,72,null,null]]},
  {title:'星港晚潮',bpm:76,bars:16,instrument:'flute',transpose:-5,
   melody:[[79,null,null,76,74,null,72,null],[77,null,79,null,81,null,79,null],[76,null,72,null,69,null,72,null],[74,null,79,null,77,null,74,null],
    [76,null,79,null,84,null,79,null],[81,null,null,79,77,null,74,null],[76,null,79,null,81,null,76,null],[74,null,71,null,67,null,null,null],
    [72,null,76,null,79,null,76,null],[77,null,81,null,79,null,77,null],[76,null,null,72,69,null,72,null],[74,null,77,null,79,null,77,null],
    [76,null,74,null,72,null,76,null],[77,null,76,null,74,null,72,null],[69,null,72,null,76,null,74,null],[71,null,72,null,72,null,null,null]]}
 ];
 for(const t of tracks)t.duration=t.bars*4*60/t.bpm+.8;
 const chords=[[48,52,55],[53,57,60],[45,48,52],[43,47,50]];
 const freq=midi=>440*Math.pow(2,(midi-69)/12);
 function eventsFor(index){
  const t=tracks[((index%tracks.length)+tracks.length)%tracks.length],beat=60/t.bpm,events=[];
  const add=(time,midi,duration,volume,instrument)=>events.push({time,midi:midi+t.transpose,duration,volume,instrument});
  for(let bar=0;bar<t.bars;bar++){
   const at=bar*4*beat,chord=chords[bar%4];
   // A soft bass pulse, broken chords and an independent singable melody.
   add(at,chord[0]-12,beat*1.75,.060,'bass');add(at+beat*2,chord[0]-12,beat*1.6,.046,'bass');
   for(let j=0;j<8;j++){const k=[0,1,2,1,0,2,1,2][j];add(at+j*beat/2,chord[k]+12,beat*.72,index===2?.020:.029,'pluck');}
   for(const note of chord)add(at,note+12,beat*3.7,.012,'pad');
   t.melody[bar].forEach((note,j)=>{if(note!==null){let next=j+1;while(next<8&&t.melody[bar][next]===null)next++;add(at+j*beat/2,note,Math.max(.16,(next-j)*beat*.44),.082,t.instrument);}});
  }
  return events.sort((a,b)=>a.time-b.time);
 }
 function voice(ctx,destination,event,start,active){
  const time=Math.max(ctx.currentTime,start),o=ctx.createOscillator(),g=ctx.createGain(),kind=event.instrument;
  const length=event.duration,attack=kind==='flute'?.060:kind==='pad'?.20:.009;
  o.type=kind==='pluck'?'triangle':'sine';o.frequency.setValueAtTime(freq(event.midi),time);
  if(kind==='marimba')o.frequency.exponentialRampToValueAtTime(freq(event.midi)*.998,time+Math.min(length,.15));
  const amp=event.volume;
  g.gain.setValueAtTime(.00001,time);g.gain.linearRampToValueAtTime(amp,time+Math.min(attack,length*.3));
  if(kind==='pluck'||kind==='marimba'||kind==='bass')g.gain.exponentialRampToValueAtTime(Math.max(.00002,amp*.22),time+length*.65);
  else g.gain.setValueAtTime(amp*.75,time+length*.60);
  g.gain.exponentialRampToValueAtTime(.00001,time+length+.12);
  o.connect(g);g.connect(destination);o.start(time);o.stop(time+length+.14);
  if(active){active.add(o);o.onended=()=>{active.delete(o);o.disconnect();g.disconnect();};}
  return o;
 }
 function create(ctx,destination,options={}){
  const active=new Set();let index=0,playing=false,timer=null,startAt=0,eventIndex=0,events=[];
  // Per-player bus permits immediate cleanup without touching the user's master gain.
  const bus=ctx.createGain();bus.gain.value=1;bus.connect(destination);
  function announce(){if(typeof options.onTrack==='function')options.onTrack({...tracks[index],index});}
  function begin(next,time){index=(next+tracks.length)%tracks.length;startAt=time;eventIndex=0;events=eventsFor(index);announce();}
  function clearVoices(){for(const o of active){try{o.stop();}catch{}try{o.disconnect();}catch{}}active.clear();}
  function tick(){
   if(!playing)return;
   const now=ctx.currentTime;
   if(now>=startAt+tracks[index].duration)begin(index+1,now+.08);
   while(eventIndex<events.length&&startAt+events[eventIndex].time<now+.75){const e=events[eventIndex++];if(startAt+e.time+e.duration>now)voice(ctx,bus,e,startAt+e.time,active);}
  }
  return {
   start(){if(playing)return;playing=true;begin(index,ctx.currentTime+.08);tick();timer=setInterval(tick,100);},
   stop(){playing=false;if(timer!==null)clearInterval(timer);timer=null;clearVoices();},
   next(){clearVoices();begin(index+1,ctx.currentTime+.08);if(playing)tick();},
   get current(){return {...tracks[index],index,elapsed:playing?Math.max(0,ctx.currentTime-startAt):0};},
   get index(){return index;},get playing(){return playing;}
  };
 }
 function renderTrack(ctx,index,{seconds=12,destination=ctx.destination}={}){
  for(const e of eventsFor(index))if(e.time<seconds)voice(ctx,destination,e,e.time,null);
  return {title:tracks[((index%tracks.length)+tracks.length)%tracks.length].title,seconds};
 }
 return {tracks,create,eventsFor,renderTrack};
});
