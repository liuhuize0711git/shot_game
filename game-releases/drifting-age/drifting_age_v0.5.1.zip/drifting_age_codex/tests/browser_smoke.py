"""Real Chromium/WebGL integration. Requires Python Playwright and system Chromium.
Run python3 tests/browser_smoke.py from the project root. Starts an isolated server;
set TEST_BASE only to use a dedicated existing server instead.
Only the test-served HTML receives a closure hook; production exposes no test API.
"""
from pathlib import Path
import json, re, os, socket, subprocess, atexit, time
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
BASE=os.environ.get('TEST_BASE')
if not BASE:
 with socket.socket() as probe:
  probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
 server=subprocess.Popen(['node','server.js'],env={**os.environ,'PORT':str(port)},stdout=subprocess.DEVNULL)
 def cleanup():
  if server.poll() is None:server.terminate();server.wait(timeout=5)
 atexit.register(cleanup)
 BASE=f'http://127.0.0.1:{port}'
 for _ in range(100):
  try:
   with urlopen(BASE) as response:assert response.status==200
   break
  except OSError:time.sleep(.05)
 else:raise RuntimeError('Isolated test server failed to start')
ART=Path('docs/artifacts');ART.mkdir(parents=True,exist_ok=True)
SOURCE=Path('public/index.html').read_text()
HOOK='''window.qa={
 get(){return {me:JSON.parse(JSON.stringify(me)),state:JSON.parse(JSON.stringify(state)),input:{...input},bindings:{...bindings},webgl:!!gl&&!!program,glError:gl&&gl.getError(),renderError,camYaw,musicVolume,sfxVolume};},
 fresh(){camYaw=0;state=freshState();me=freshPlayer();state.players=[me];OceanMovement.normalize(state,me);input={};gameStarted=false;mode='solo';syncHUD();},
 set(p){Object.assign(me,p);delete me.motion;delete me.boarding;OceanMovement.normalize(state,me);},
 tick(keys,seconds){input={...keys};const was=gameStarted;gameStarted=true;for(let t=0;t<seconds-1e-8;t+=1/60)updateLocal(Math.min(1/60,seconds-t));gameStarted=was;input={};syncHUD();return JSON.parse(JSON.stringify(me));},
 act(a,d){return localAction(a,d||{});},
 active(v){gameStarted=v;}, keys(k){input={...k};sendInputs();},
 drop(){me.selectedSlot=4;return localAction('drop',{key:'plank'});},
 view(yaw){camYaw=yaw;},save(){saveSolo();},
 };'''
INSTRUMENTED=SOURCE.replace('})();\n</script>',HOOK+'})();\n</script>')
results={}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
 context=browser.new_context(viewport={'width':1100,'height':720})
 context.route('**/index.html',lambda r:r.fulfill(body=INSTRUMENTED,content_type='text/html'))
 page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'/index.html');page.click('#startBtn');page.wait_for_timeout(300)
 assert page.evaluate('document.pointerLockElement===document.querySelector("#gl")')
 oldyaw=page.evaluate('qa.get().camYaw');page.mouse.move(580,330);assert page.evaluate('qa.get().camYaw')!=oldyaw
 assert page.evaluate('qa.get().webgl')
 page.evaluate('qa.fresh()');assert page.evaluate('qa.get().state.raft.length')==9
 page.wait_for_timeout(200);page.screenshot(path=str(ART/'v0.5.1-scene.png'))
 results['1_new_world']='PASS: exactly 9 raft tiles; real WebGL context'
 p=page.evaluate('qa.tick({right:true},1.4)');assert p['altitude']<.52 and p['x']>572
 results['2_enter_water']='PASS: walked off the edge via actual client update loop; continuous trajectory also asserted in node suite'
 page.evaluate('qa.tick({},2)');a=page.evaluate('qa.get().me.altitude');page.evaluate('qa.tick({},.5)');b=page.evaluate('qa.get().me.altitude');assert b<a
 results['3_sink']='PASS: released Space sinks beyond old -1.05 dead zone'
 page.evaluate('qa.tick({upward:true},6)');p=page.evaluate('qa.get().me');assert abs(p['altitude']+.34)<.001
 results['4_ascend']='PASS: reaches -0.34 surface, never deck; gradual trajectory asserted in node suite'
 page.evaluate('qa.tick({left:true,upward:true},1.2)');assert page.evaluate('qa.act("pickup").ok');page.evaluate('qa.tick({},1.3)');p=page.evaluate('qa.get().me');assert p['motion']=='RAFT_GROUNDED'
 page.wait_for_timeout(200);page.screenshot(path=str(ART/'v0.5.1-reboarded.png'))
 results['5_reboard']='PASS: client pickup action boards exposed edge, then grounded on supported tile'
 page.evaluate('qa.set({x:500,y:350,altitude:-2})');page.evaluate('qa.tick({upward:true},3)');assert page.evaluate('qa.get().me.altitude')==-.72
 page.evaluate('qa.tick({right:true,upward:true},1.6)');page.evaluate('qa.tick({upward:true},2)');assert page.evaluate('qa.get().me.altitude')==-.34
 results['6_underside_escape']='PASS: blocked at -0.72; horizontal swim out and ascent work'
 page.evaluate('qa.set({x:890,y:290,altitude:-2})');page.evaluate('qa.tick({left:true},1)');page.evaluate('qa.tick({upward:true},4)');assert page.evaluate('qa.act("pickup").ok');page.evaluate('qa.tick({},1.3)');assert page.evaluate('qa.get().me.motion')=='ISLAND_GROUNDED'
 page.evaluate('qa.tick({left:true},.8)');page.evaluate('qa.view(1.2)');page.wait_for_timeout(300);page.screenshot(path=str(ART/'v0.5.1-shore.png'));page.evaluate('qa.view(0)')
 page.evaluate('qa.tick({right:true},3)');assert page.evaluate('qa.get().me.altitude')<0
 results['7_island']='PASS: underwater island blocks entry; surface landing, inland walk and re-entry work'
 page.evaluate('qa.set({x:590,y:400,altitude:-2,oxygen:100})');page.evaluate('qa.tick({},1)');assert page.evaluate('qa.get().me.oxygen')<100
 page.evaluate('qa.tick({upward:true},6)');assert page.evaluate('qa.get().me.oxygen')==100
 results['8_oxygen']='PASS: depletion underwater and recovery at surface; grounded recovery in node suite'
 # Collect a real seabed node and capture the actual underwater renderer.
 page.evaluate('qa.set({x:420,y:465,altitude:-7.25})');before=page.evaluate('qa.get().me.inventory.metal||0');assert page.evaluate('qa.act("pickup").ok');assert page.evaluate('qa.get().me.inventory.metal')==before+1
 page.wait_for_timeout(200);page.screenshot(path=str(ART/'v0.5.1-underwater.png'))
 results['seabed_resources']='PASS: real underwater scene, metal node removed and inventory incremented'
 # Test actual keyboard/UI handlers with physics paused.
 page.evaluate('qa.active(true)');page.keyboard.press('0');assert page.evaluate('qa.get().me.selectedSlot')==9
 page.keyboard.press('ArrowRight');assert page.evaluate('qa.get().me.selectedSlot')==0
 page.keyboard.press('ArrowLeft');assert page.evaluate('qa.get().me.selectedSlot')==9
 page.evaluate('qa.active(false)');page.evaluate('qa.fresh()');old=page.evaluate('qa.get().me.inventory.plank');page.evaluate('qa.active(true)');page.keyboard.press('5');page.keyboard.press('t');page.evaluate('qa.active(false)');assert page.evaluate('qa.get().me.inventory.plank')==old-1
 page.evaluate('qa.act("pickup")');assert page.evaluate('qa.get().me.inventory.plank')==old
 page.evaluate('document.exitPointerLock()');page.click('#settingsBtn');page.locator('.bind-btn').first.click();page.keyboard.press('e');assert page.evaluate('qa.get().bindings.forward')=='w'
 page.locator('#musicVolume').fill('35');page.locator('#musicVolume').dispatch_event('input');assert page.evaluate('qa.get().musicVolume')==.35
 page.click('#settingsDone');page.evaluate('qa.active(true)');assert page.evaluate('qa.act("craft",{key:"spear"}).ok');page.evaluate('qa.set({x:180,y:520,altitude:-.34})');page.keyboard.press('2');page.click('#cameraBtn');assert page.evaluate('document.pointerLockElement===document.querySelector("#gl")');before=page.evaluate('qa.get().state.shark.hp||100');page.mouse.click(550,360);assert page.evaluate('qa.get().state.shark.hp')==before-22;page.keyboard.press('Escape');page.wait_for_timeout(100);assert page.evaluate('document.pointerLockElement===null');page.evaluate('qa.active(false)');page.evaluate('qa.save()');assert page.evaluate('!!localStorage.getItem("driftingAge3dSave")')
 results['regression_ui']='PASS: actual pointer lock, mouse look, Esc release, left-click spear damage, 10 slots, numeric/arrow keys, T drop/pickup quantities, binding conflict rejection, audio setting and local save'
 # Two real online browsers, moving only via ordinary control/action protocol.
 online=browser.new_context(viewport={'width':800,'height':600},permissions=['local-network-access'])
 online.route('**/index.html',lambda r:r.fulfill(body=INSTRUMENTED,content_type='text/html'))
 clients=[online.new_page(),online.new_page()]
 for c in clients:
  c.on('pageerror',lambda e:errors.append(str(e)));c.goto(BASE+'/index.html');c.evaluate("setTimeout(()=>{},0)")
  c.locator('[data-mode="coop"]').click();c.click('#startBtn');c.wait_for_function('qa.get().me && qa.get().state.players.length>=1');c.evaluate('qa.view(0)')
 a,b=clients;print('Two peers connected',flush=True);a.wait_for_function('qa.get().state.players.length===2')
 def wait(expr,timeout=15000):
  print('WAIT',expr,flush=True)
  try:a.wait_for_function(expr,timeout=timeout,polling=100)
  except Exception:
   print('PLAYER',a.evaluate('qa.get().me'),flush=True);raise
 def keys(k):a.evaluate('(k)=>qa.keys(k)',k)
 keys({'right':True});wait('qa.get().me.x>578');keys({});wait('qa.get().me.altitude<-1.2')
 depth=a.evaluate('qa.get().me.altitude');a.wait_for_timeout(500);assert a.evaluate('qa.get().me.altitude')<depth
 keys({'left':True});wait('qa.get().me.x<520');keys({'upward':True});wait('Math.abs(qa.get().me.altitude+.72)<.001')
 a.wait_for_timeout(300);assert a.evaluate('qa.get().me.motion')=='UNDERWATER'
 keys({'right':True,'upward':True});wait('qa.get().me.x>578');keys({'upward':True});wait('Math.abs(qa.get().me.altitude+.34)<.001')
 keys({'left':True,'upward':True});wait('OceanMovement.boardingTarget(qa.get().state,qa.get().me)?.kind === "raft"');keys({'upward':True});a.keyboard.press('e');wait('qa.get().me.motion==="RAFT_GROUNDED"');keys({})
 a.wait_for_timeout(250);aid=a.evaluate('qa.get().me.id');observed=b.evaluate('(id)=>qa.get().state.players.find(p=>p.id===id)',aid);assert observed['motion']=='RAFT_GROUNDED' and abs(observed['altitude']-.52)<.001
 # Ignore spoofed altitude/motion in input messages: server consumes controls only.
 a.evaluate("qa.keys({altitude:90,x:0,motion:'ISLAND_GROUNDED'})");a.wait_for_timeout(300);assert a.evaluate('qa.get().me.altitude')==.52
 keys({'right':True});wait('qa.get().me.x>580');keys({'upward':True});wait('Math.abs(qa.get().me.altitude+.34)<.001')
 keys({'right':True,'upward':True});wait('OceanMovement.boardingTarget(qa.get().state,qa.get().me)?.kind === "island"');keys({'upward':True});a.keyboard.press('e');wait('qa.get().me.motion==="ISLAND_GROUNDED"');keys({})
 a.wait_for_timeout(200);observed=b.evaluate('(id)=>qa.get().state.players.find(p=>p.id===id)',aid);assert observed['motion']=='ISLAND_GROUNDED'
 keys({'right':True});a.wait_for_timeout(500);keys({'left':True});wait('qa.get().me.altitude<-.4');keys({});wait('qa.get().me.oxygen<99')
 keys({'upward':True});wait('qa.get().me.altitude===-.34');wait('qa.get().me.oxygen===100');keys({'upward':True})
 results['9_multiplayer_water']='PASS: two browser clients, sink/ascent, underside/escape, E boarding, island landing/walk/re-entry, oxygen and shared states; spoofed position ignored'
 # Third peer capacity, then disconnect/reconnect without ghosts.
 full=a.evaluate('''() => new Promise(resolve=>{const s=new WebSocket(`ws://${location.host}/?name=third`);s.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='full')resolve(m.type);};setTimeout(()=>resolve('timeout'),3000);})''');assert full=='full'
 b.close();a.wait_for_function('qa.get().state.players.length===1')
 reconnect=online.new_page();reconnect.goto(BASE+'/index.html');reconnect.locator('[data-mode="coop"]').click();reconnect.click('#startBtn');reconnect.wait_for_function('qa.get().state.players.length===2');a.wait_for_function('qa.get().state.players.length===2')
 results['network_capacity_reconnect']='PASS: third peer rejected; disconnect removes player and replacement rejoins'
 assert not errors,errors
 assert page.evaluate('qa.get().webgl && !qa.get().renderError && qa.get().glError===0')
 results['10_browser_visual']='PASS: real Chromium WebGL rendering, GL_NO_ERROR, no page exceptions; scene/reboard/shore screenshots captured'
 browser.close()
Path('docs/browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
