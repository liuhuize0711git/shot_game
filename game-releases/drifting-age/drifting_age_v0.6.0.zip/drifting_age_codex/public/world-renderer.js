/* Original procedural islands, vegetation and wildlife. Uses the same height
 * function as player movement; no remote models, textures or runtime assets. */
(function(root){
 'use strict';
 const cache=new Map();
 const palettes={
  palm:{sand:[.82,.71,.48],grass:[.28,.56,.28],rock:[.45,.47,.39]},
  meadow:{sand:[.75,.68,.47],grass:[.36,.56,.30],rock:[.47,.49,.45]},
  ridge:{sand:[.68,.64,.48],grass:[.32,.46,.30],rock:[.45,.48,.50]}
 };
 const px=x=>(x-500)/30,pz=y=>(y-350)/30;
 function terrainMeshes(i,api){
  const W=root.OceanWorld,key=JSON.stringify([i.id,i.x,i.y,i.rx,i.rz,i.radius,i.height,i.seed,i.biome]);
  if(cache.has(key))return cache.get(key);
  const rx=i.rx||i.radius,rz=i.rz||i.radius,segments=56,rings=22;
  const groups={sand:{p:[],n:[],i:[]},grass:{p:[],n:[],i:[]},skirt:{p:[],n:[],i:[]}};
  function vertex(r,a){
   const x=i.x+Math.cos(a)*rx*r,y=i.y+Math.sin(a)*rz*r,h=W.terrain(i,x,y).height;
   const e=.15,dx=(W.terrain(i,x+e,y).height-W.terrain(i,x-e,y).height)/(2*e/30),dz=(W.terrain(i,x,y+e).height-W.terrain(i,x,y-e).height)/(2*e/30),l=Math.hypot(dx,1,dz);
   return {p:[(x-i.x)/30,h,(y-i.y)/30],n:[-dx/l,1/l,-dz/l]};
  }
  function quad(g,a,b,c,d){const k=g.p.length/3;for(const v of [a,b,c,d]){g.p.push(...v.p);g.n.push(...v.n);}g.i.push(k,k+2,k+1,k,k+3,k+2);}
  for(let r=0;r<rings;r++)for(let s=0;s<segments;s++){
   const a=s*Math.PI*2/segments,b=(s+1)*Math.PI*2/segments;
   quad(groups[r/rings>=.77?'sand':'grass'],vertex(r/rings,a),vertex((r+1)/rings,a),vertex((r+1)/rings,b),vertex(r/rings,b));
  }
  for(let s=0;s<segments;s++){
   const a=s*Math.PI*2/segments,b=(s+1)*Math.PI*2/segments,va=vertex(1,a),vb=vertex(1,b);
   const ba={p:[Math.cos(a)*rx/30*1.08,-7.6,Math.sin(a)*rz/30*1.08],n:[Math.cos(a),.15,Math.sin(a)]};
   const bb={p:[Math.cos(b)*rx/30*1.08,-7.6,Math.sin(b)*rz/30*1.08],n:[Math.cos(b),.15,Math.sin(b)]};
   quad(groups.skirt,va,ba,bb,vb);
  }
  const result={};for(const [k,g] of Object.entries(groups))result[k]=api.makeMesh(g.p,g.n,g.i);
  cache.set(key,result);return result;
 }
 function drawTree(t,i,api){
  const {draw:d,meshes:m,elapsed:time=0,gl}=api,x=px(t.x),z=pz(t.y),base=root.OceanWorld.terrain(i,t.x,t.y).height;
  const brown=[.46,.29,.15],darkBrown=[.32,.20,.12],leaf=[.18,.46,.23],sway=Math.sin(time*.7+(t.phase||0)+t.x)*.035;
  if(t.hp<=0){d(m.cylinder,x,base+.12,z,.29,.24,.29,brown);d(m.cylinder,x,base+.244,z,.24,.012,.24,[.73,.55,.32]);return;}
  if(api.highlightTreeId===t.id){for(let j=0;j<12;j++){const a=j*Math.PI/6;d(m.sphere,x+Math.cos(a)*.34,base+.08,z+Math.sin(a)*.34,.09,.06,.09,[1,.80,.25]);}}
  if(t.kind==='palm'){
   d(m.cylinder,x+sway,base+1.12,z,.20,2.24,.20,brown,0,false,0,sway);
   for(let j=0;j<4;j++)d(m.cylinder,x+sway*.5,base+.30+j*.44,z,.205,.045,.205,darkBrown);
   d(m.sphere,x+sway,base+2.28,z,.35,.22,.35,leaf);
   if(gl)gl.disable(gl.CULL_FACE);
   for(let j=0;j<7;j++)d(m.leafBlade||m.sphere,x+sway,base+2.26,z,1.10+(j%2)*.14,1.1,1.3,[.16,.44+(j%2)*.07,.22],j*Math.PI*2/7,false,0,-.15+sway);
   if(gl)gl.enable(gl.CULL_FACE);
   for(let j=0;j<3;j++){const a=j*2.1;d(m.sphere,x+Math.cos(a)*.15,base+2.07,z+Math.sin(a)*.15,.17,.19,.17,[.45,.29,.13]);}
  }else if(t.kind==='pine'){
   d(m.cylinder,x,base+1.2,z,.24,2.4,.24,brown);
   for(let j=0;j<3;j++)d(m.cone,x+sway,base+1.1+j*.65,z,1.5-j*.34,1.5-j*.22,1.5-j*.34,[.15,.35+j*.03,.25],0,false,0,sway);
  }else{
   d(m.cylinder,x,base+1.05,z,.28,2.1,.28,brown);
   for(let j=0;j<3;j++){const a=j*2.1;d(m.cylinder,x+Math.sin(a)*.3,base+1.65,z+Math.cos(a)*.3,.12,.9,.12,brown,a,false,.7);d(m.sphere,x+Math.sin(a)*.48+sway,base+2.2+(j%2)*.35,z+Math.cos(a)*.48,1.25,1.05,1.15,[.21,.47+j*.035,.23]);}
  }
 }
 function drawAnimal(a,api){
  const {draw:d,meshes:m,elapsed=0}=api,x=px(a.x),z=pz(a.y),yaw=a.yaw||0,cy=a.altitude||0;
  const sin=Math.sin(yaw),cos=Math.cos(yaw),phase=elapsed*4.6+(a.phase||0);
  function part(mesh,lx,ly,lz,sx,sy,sz,color,rx=0,rz=0){d(mesh,x+lx*cos+lz*sin,cy+ly,z-lx*sin+lz*cos,sx,sy,sz,color,yaw,false,rx,rz);}
  const dark=[.14,.12,.10],white=[.92,.89,.78],hoof=[.24,.20,.17];
  if(a.species==='gull'||a.species==='parrot'){
   const parrot=a.species==='parrot',body=parrot?[.22,.66,.35]:[.93,.94,.85],wing=parrot?[.15,.44,.70]:[.64,.70,.73],flap=Math.sin(elapsed*7+(a.phase||0))*.65;
   part(m.sphere,0,0,0,.24,.26,.48,body);part(m.sphere,0,.17,-.23,.23,.24,.25,body);
   part(m.cone,0,.13,-.42,.09,.22,.09,[.95,.67,.20],-Math.PI/2);
   for(const side of [-1,1]){part(m.sphere,side*.32,Math.abs(flap)*.1,.02,.66,.055,.22,wing,0,side*flap);part(m.sphere,side*.10,.20,-.29,.035,.04,.035,dark);}
   part(m.cone,0,-.04,.36,.16,.35,.10,parrot?[.88,.35,.23]:white,Math.PI/2);
   return;
  }
  const horse=a.species==='horse',goat=a.species==='goat',body=horse?[.60,.35,.20]:goat?[.88,.84,.69]:[.40,.29,.21],s=horse?1.3:goat?.82:.93;
  function p(mesh,lx,ly,lz,sx,sy,sz,color,rx=0,rz=0){part(mesh,lx*s,ly*s,lz*s,sx*s,sy*s,sz*s,color,rx,rz);}
  p(m.sphere,0,horse?.91:.64,0,.65,horse?.67:.58,1.12,body);
  for(let leg=0;leg<4;leg++){
   const side=leg%2?1:-1,front=leg<2?-1:1,swing=Math.sin(phase+(leg===0||leg===3?0:Math.PI))*.22,legLen=horse?.65:goat?.43:.32;
   p(m.cylinder,side*.22,legLen/2+.08,front*.36+swing*.15,.105,legLen,.12,body,swing);
   p(m.sphere,side*.22,.075,front*.36+swing*.26,.15,.14,.19,hoof);
  }
  if(horse){
   p(m.sphere,0,1.27,-.42,.38,.90,.42,body,.35);
   p(m.sphere,0,1.70,-.67,.36,.39,.64,body,.22);
   p(m.sphere,0,1.60,-.97,.28,.24,.25,[.35,.24,.20]);
   p(m.sphere,0,1.35,-.18,.19,.83,.23,dark,.35);
   p(m.sphere,0,.71,.65,.17,.71,.16,dark,-.25);
   for(const side of [-1,1])p(m.cone,side*.13,1.98,-.54,.13,.30,.12,body,0,-side*.16);
  }else if(goat){
   p(m.sphere,0,.94,-.49,.32,.46,.35,body,.2);
   p(m.sphere,0,1.12,-.61,.38,.34,.44,body);
   p(m.sphere,0,1.03,-.84,.25,.22,.20,[.63,.56,.43]);
   p(m.cone,0,.89,-.70,.16,.29,.14,white,Math.PI);
   for(const side of [-1,1]){p(m.cone,side*.13,1.40,-.49,.09,.42,.09,[.50,.44,.34],-.32,-side*.12);p(m.sphere,side*.25,1.14,-.52,.26,.09,.16,body,0,side*.2);}
   p(m.sphere,0,.85,.60,.12,.25,.12,white,-.7);
  }else{
   p(m.sphere,0,.71,-.49,.58,.50,.52,body);
   p(m.sphere,0,.60,-.83,.36,.26,.22,[.65,.43,.33]);
   for(const side of [-1,1]){p(m.cone,side*.21,.98,-.47,.20,.30,.15,body,.25,-side*.32);p(m.cone,side*.20,.57,-.82,.08,.24,.08,[.94,.87,.65],.40,-side*.3);p(m.sphere,side*.07,.62,-.95,.04,.05,.025,dark);}
   p(m.sphere,0,.85,.62,.10,.10,.24,body);
   for(let j=0;j<5;j++)p(m.cone,0,.97,-.1+j*.12,.07,.15,.07,dark);
  }
  for(const side of [-1,1])p(m.sphere,side*(horse?.17:goat?.17:.25),horse?1.77:goat?1.18:.79,horse?-.76:goat?-.69:-.66,.05,.055,.055,dark);
 }
 function draw(w,api){
  if(!root.OceanWorld||!w?.islands)return;
  for(const i of w.islands){
   const terrain=terrainMeshes(i,api),palette=palettes[i.biome]||palettes.palm,x=px(i.x),z=pz(i.y);
   api.draw(terrain.skirt,x,0,z,1,1,1,palette.rock);
   api.draw(terrain.sand,x,0,z,1,1,1,palette.sand);
   api.draw(terrain.grass,x,0,z,1,1,1,palette.grass);
   for(let k=0;k<7;k++){
    const a=k*2.399+(i.seed||0),r=.36+(k%3)*.12,tx=i.x+Math.cos(a)*(i.rx||i.radius)*r,ty=i.y+Math.sin(a)*(i.rz||i.radius)*r,ground=root.OceanWorld.terrain(i,tx,ty).height;
    const size=i.biome==='ridge'?.55:.30;
    api.draw(api.meshes.sphere,px(tx),ground+size*.18,pz(ty),size*1.4,size*.5,size,palette.rock,a);
   }
   for(const t of w.trees||[])if(t.islandId===i.id)drawTree(t,i,api);
  }
  for(const a of w.animals||[])drawAnimal(a,api);
 }
 root.OceanWorldRenderer={draw};
})(typeof globalThis!=='undefined'?globalThis:this);
