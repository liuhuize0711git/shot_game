const http = require('http');
const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');
const crypto = require('crypto');
const OceanMovement = require('./public/movement.js');
const OceanItems = require('./public/items.js');
const OceanTargeting = require('./public/targeting.js');

const PORT = Number(process.env.PORT || 3000);
const PUBLIC = path.join(__dirname, 'public');
const TILE = 48;
const ORIGIN = { x: 500, y: 350 };
const MAX_PLAYERS = 2;
const mime = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8', '.png':'image/png', '.svg':'image/svg+xml' };

const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || '/').split('?')[0]);
  if (pathname === '/') pathname = '/index.html';
  const file = path.normalize(path.join(PUBLIC, pathname));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
});
const sockets = new Set();
const WS_OPEN = 1;
function wsFrame(opcode, payload) {
  const data = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  let header;
  if (data.length < 126) { header = Buffer.from([0x80 | opcode, data.length]); }
  else if (data.length < 65536) { header = Buffer.alloc(4); header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(data.length, 2); }
  else { header = Buffer.alloc(10); header[0] = 0x80 | opcode; header[1] = 127; header.writeBigUInt64BE(BigInt(data.length), 2); }
  return Buffer.concat([header, data]);
}
function makeWebSocket(socket) {
  const ws = { socket, readyState: WS_OPEN, playerId: null, buffer: Buffer.alloc(0), handlers: { message: [], close: [] },
    send(text) { if (this.readyState === WS_OPEN && !socket.destroyed) socket.write(wsFrame(1, String(text))); },
    close(code=1000, reason='') { if (this.readyState !== WS_OPEN) return; const r=Buffer.from(String(reason).slice(0,120)); const payload=Buffer.alloc(2+r.length); payload.writeUInt16BE(code,0); r.copy(payload,2); try{socket.write(wsFrame(8,payload));}catch{} this.readyState=3; socket.end(); },
    on(event, fn) { if(this.handlers[event]) this.handlers[event].push(fn); },
    emit(event, value) { for(const fn of this.handlers[event]||[]) { try{fn(value);}catch(e){console.error(e);} } }
  };
  function parseFrames(chunk) {
    ws.buffer = Buffer.concat([ws.buffer, chunk]);
    while(ws.buffer.length >= 2) {
      const b0=ws.buffer[0], b1=ws.buffer[1], opcode=b0&0x0f, masked=!!(b1&0x80); let len=b1&0x7f, off=2;
      if(len===126){if(ws.buffer.length<4)return;len=ws.buffer.readUInt16BE(2);off=4;}
      else if(len===127){if(ws.buffer.length<10)return;const big=ws.buffer.readBigUInt64BE(2);if(big>4096n){ws.close(1009,'Payload too large');return;}len=Number(big);off=10;}
      if(len>4096){ws.close(1009,'Payload too large');return;}
      const maskBytes=masked?4:0;if(ws.buffer.length<off+maskBytes+len)return;
      let payload=ws.buffer.subarray(off+maskBytes,off+maskBytes+len);
      if(masked){const mask=ws.buffer.subarray(off,off+4);payload=Buffer.from(payload);for(let i=0;i<payload.length;i++)payload[i]^=mask[i%4];}
      ws.buffer=ws.buffer.subarray(off+maskBytes+len);
      if(opcode===8){ws.readyState=3;socket.end();return;}
      if(opcode===9){socket.write(wsFrame(10,payload));continue;}
      if(opcode===1)ws.emit('message',payload);
    }
  }
  socket.on('data',parseFrames);
  socket.on('close',()=>{if(ws.readyState!==3)ws.readyState=3;ws.emit('close');sockets.delete(ws);});
  socket.on('error',()=>{if(ws.readyState!==3)ws.readyState=3;ws.emit('close');sockets.delete(ws);});
  sockets.add(ws); return ws;
}
server.on('upgrade',(req,socket,head)=>{
  const key=req.headers['sec-websocket-key'];
  if(!key || req.headers.upgrade?.toLowerCase()!=='websocket'){socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');socket.destroy();return;}
  const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
  const ws=makeWebSocket(socket); attachConnection(ws,req); if(head&&head.length) socket.emit('data',head);
});

const recipes = {
  purifier: { name:'海水淡化器', cost:{ plank:6, plastic:4, leaf:3 }, station:true },
  grill: { name:'简易烤架', cost:{ plank:4, scrap:2 }, station:true },
  net: { name:'漂流收集网', cost:{ plank:5, leaf:4 }, station:true },
  sail: { name:'帆与桅杆', cost:{ plank:6, leaf:4 }, station:true },
  chest: { name:'储物箱', cost:{ plank:4, plastic:2 }, station:true },
  spear: { name:'金属尖矛', cost:{ plank:3, scrap:3 }, tool:true },
  axe: { name:'简易斧', cost:{ plank:3, scrap:2 }, tool:true },
  rod: { name:'钓鱼竿', cost:{ plank:3, leaf:2 }, tool:true },
  bottle: { name:'水瓶', cost:{ plastic:3 }, tool:true },
  armor: { name:'拼接护甲', cost:{ scrap:5, leaf:3 }, tool:true }
};
const itemNames = { plank:'木板', plastic:'塑料', leaf:'棕榈叶', scrap:'废料', stone:'石头', potato:'土豆', raw_fish:'生鱼', food:'熟食', water:'淡水', metal:'金属矿', copper:'铜矿', seaweed:'海草', trash:'垃圾方块' };
Object.assign(itemNames,{hook:'生存钩',spear:'尖矛',axe:'斧头',rod:'鱼竿',bottle:'水瓶',armor:'护甲',purifier:'海水淡化器',grill:'烤架',net:'收集网',sail:'船帆',chest:'储物箱'});
const colors = { plank:'#c68a52', plastic:'#9ee7e8', leaf:'#61b66c', scrap:'#aeb7c3', stone:'#a5a6ad', potato:'#d5a65c', barrel:'#d58e50' };
const state = {
  startedAt: Date.now(), players: {}, resources: [], underwaterResources:[{id:'ore_m1',type:'metal',x:420,y:465,depth:-7.25},{id:'ore_c1',type:'copper',x:575,y:465,depth:-7.2},{id:'ore_m2',type:'metal',x:625,y:320,depth:-7.25},{id:'ore_s1',type:'stone',x:360,y:300,depth:-7.2},{id:'seaweed1',type:'seaweed',x:445,y:275,depth:-7.15},{id:'seaweed2',type:'seaweed',x:560,y:515,depth:-7.15},{id:'ore_c2',type:'copper',x:525,y:535,depth:-7.2}], raft: [], stations: { purifier:0, grill:0, net:0, sail:0, chest:0 },
  shark: { x:160, y:520, mood:'巡游' }, island: { x:740, y:290, radius:120 }, events: [],
  nextResource: 0, sharkTimer: 24, netTimer: 18
};
for (let gx=-1; gx<=1; gx++) for (let gy=-1; gy<=1; gy++) state.raft.push({ gx, gy, hp:100, armored:false });
spawnResource('plank', 390, 265); spawnResource('plastic', 612, 265); spawnResource('leaf', 375, 450); spawnResource('scrap', 630, 430); spawnResource('barrel', 300, 330);

function addEvent(message) {
  state.events.unshift({ id: randomUUID().slice(0,8), text: message, at: Date.now() });
  state.events = state.events.slice(0, 6);
}
function rand(min,max){ return Math.random()*(max-min)+min; }
function clamp(n,min,max){ return Math.max(min,Math.min(max,n)); }
function playerCount(){ return Object.keys(state.players).length; }
function isOverRaft(p){return OceanMovement.overRaft(state,p);}
function isOnRaft(p){return OceanMovement.onRaft(state,p);}
function isOnIsland(p){return OceanMovement.onIsland(state,p);}
function invCount(p,key){ return Number(p.inventory[key]||0); }
function take(p,cost){
  for(const [k,v] of Object.entries(cost)) if(invCount(p,k)<v) return false;
  for(const [k,v] of Object.entries(cost)) p.inventory[k]-=v;
  return true;
}
function spawnResource(type, x, y, amount=1){
  state.resources.push({ id:randomUUID().slice(0,10), type, x, y, amount, phase:Math.random()*6.28 });
}
function spawnDebris(){
  const types = ['plank','plank','plastic','leaf','scrap','stone','barrel'];
  const side = Math.floor(Math.random()*4);
  let x,y;
  if(side===0){x=rand(30,970);y=20;} else if(side===1){x=980;y=rand(30,670);} else if(side===2){x=rand(30,970);y=680;} else {x=20;y=rand(30,670);}
  const type=types[Math.floor(Math.random()*types.length)];
  spawnResource(type,x,y,type==='barrel'?1:1);
}
function cleanPlayer(p){
  return { id:p.id, name:p.name, x:p.x, y:p.y, motion:p.motion, surfaceSwimming:p.surfaceSwimming, boarding:p.boarding, altitude:p.altitude??.52, verticalVelocity:p.verticalVelocity||0, oxygen:p.oxygen??100, yaw:p.yaw??0, moving:!!p.moving, sprinting:!!p.keys?.sprint, animTime:p.animTime||0, selectedSlot:p.selectedSlot||0, hp:p.hp, hunger:p.hunger, thirst:p.thirst, down:p.down,
    inventory:p.inventory, tools:p.tools, hotbar:OceanItems.slots(p), color:p.color, onRaft:isOnRaft(p), onIsland:isOnIsland(p), lastSeen:p.lastSeen };
}
function snapshot(){
  return { type:'state', players:Object.values(state.players).map(cleanPlayer), resources:state.resources, underwaterResources:state.underwaterResources,
    raft:state.raft, stations:state.stations, shark:state.shark, island:state.island,
    events:state.events, recipes:Object.fromEntries(Object.entries(recipes).map(([k,v])=>[k,{name:v.name,cost:v.cost}])),
    time:Math.floor((Date.now()-state.startedAt)/1000), maxPlayers:MAX_PLAYERS };
}
function send(ws,obj){ if(ws.readyState===WS_OPEN) ws.send(JSON.stringify(obj)); }
function broadcast(){ const payload=JSON.stringify(snapshot()); for(const ws of sockets) if(ws.readyState===WS_OPEN) ws.send(payload); }

function doAction(p, action, data={}){
  if(p.down && !['revive','respawn'].includes(action)) return {ok:false,msg:'你已倒下，等待队友救援或重新出发。'};
  if(action==='board')return {ok:OceanMovement.interact(state,p),msg:'靠近水面外缘才能上岸。'};
  if(action==='select'){if(!Number.isInteger(data.slot)||data.slot<0||data.slot>9)return {ok:false,msg:'快捷栏无效。'};p.selectedSlot=data.slot;return {ok:true};}
  if(action==='equip'){const r=OceanItems.equip(state,p,data.key);return {ok:r.ok,msg:r.ok?'已拿到手上。':'没有该物品。'};}
  if(action==='pickup'){
    const selected=OceanTargeting.validate(state,p,data);
    if(!selected)return {ok:false,msg:'请把附近物品放进中央圆区，显示名称后按 E。'};
    OceanItems.collect(state,p,selected.resource,selected.underwater);
    return {ok:true,msg:`拾取了${itemNames[selected.resource.type]||selected.resource.type}`};
  }
  if(action==='drop'){
    const key=OceanItems.held(p),r=OceanItems.drop(state,p,key);
    return {ok:!!r,msg:r?`丢出了${itemNames[key]||key}。`:'当前手持物品数量为 0。'};
  }
  if(action==='attack'){
    const key=OceanItems.held(p);
    if(OceanItems.stations.includes(key))return {ok:OceanItems.place(state,p),msg:p.motion==='RAFT_GROUNDED'?'已放置设施。':'请站在木筏上放置设施。'};
    if(key!=='spear'||!(p.tools.spear||0))return {ok:false,msg:'当前手持物品没有攻击效果；制作尖矛后可左键攻击。'};
    if(Math.hypot(p.x-state.shark.x,p.y-state.shark.y)>95)return {ok:false,msg:'你挥动尖矛，但没有击中目标。'};
    state.shark.hp=(state.shark.hp??100)-22;if(state.shark.hp<=0){state.shark.hp=100;state.shark.x=rand(100,900);state.shark.y=rand(80,620);return {ok:true,msg:'鲨鱼被击退了！'};}return {ok:true,msg:'你挥动尖矛击中了鲨鱼！'};
  }
  if(action==='eat'){
    if(invCount(p,'food')>0){p.inventory.food--;p.hunger=clamp(p.hunger+32,0,100);return {ok:true,msg:'吃下一份熟食，饥饿缓解。'};}
    if(invCount(p,'potato')>0){p.inventory.potato--;p.hunger=clamp(p.hunger+14,0,100);return {ok:true,msg:'吃下土豆，暂时缓解饥饿。'};}
    return {ok:false,msg:'没有可食用的食物，去捕鱼或收集土豆。'};
  }
  if(action==='drink'){
    if(invCount(p,'water')>0){p.inventory.water--;p.thirst=clamp(p.thirst+38,0,100);return {ok:true,msg:'喝下淡水，口渴缓解。'};}
    return {ok:false,msg:'没有淡水。制作并放置海水淡化器后可以制水。'};
  }
  if(action==='craft'){
    const key=data.key, recipe=recipes[key]; if(!recipe) return {ok:false,msg:'未知配方。'};
    const result=OceanItems.craft(state,p,key,recipe);
    if(!result.ok)return {ok:false,msg:'制作材料不足。'};
    return {ok:true,msg:`制作完成，已手持${recipe.name}`+(result.dropped?'；原手持物品已丢在脚边，可瞄准捡回。':'。')};
  }
  if(action==='build'){
    const dir=data.dir; const dirs={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]}; if(!dirs[dir]) return {ok:false,msg:'选择一个扩建方向。'};
    const gx=Math.round((p.x-ORIGIN.x)/TILE), gy=Math.round((p.y-ORIGIN.y)/TILE);
    if(!isOnRaft(p)) return {ok:false,msg:'请站在木筏地板上扩建。'};
    const d=dirs[dir], horizontal=dir==='left'||dir==='right';
    const edge=state.raft.filter(t=>!state.raft.some(q=>q.gx===t.gx+d[0]&&q.gy===t.gy+d[1]))
      .sort((a,b)=>Math.abs((horizontal?a.gy:a.gx)-(horizontal?gy:gx))-Math.abs((horizontal?b.gy:b.gx)-(horizontal?gy:gx)))[0];
    if(!edge) return {ok:false,msg:'找不到可扩建的边缘。'};
    const nx=edge.gx+d[0], ny=edge.gy+d[1];
    if(state.raft.some(t=>t.gx===nx&&t.gy===ny)) return {ok:false,msg:'这个位置已经有地板。'};
    if(!take(p,{plank:4,plastic:2})) return {ok:false,msg:'扩建需要木板 ×4、塑料 ×2。'};
    state.raft.push({gx:nx,gy:ny,hp:100,armored:false}); addEvent(`${p.name} 扩建了木筏`); return {ok:true,msg:'木筏边缘已扩建一块地板。'};
  }
  if(action==='purify'){
    if(!state.stations.purifier) return {ok:false,msg:'先制作并放置海水淡化器。'};
    if(!take(p,{plank:1})) return {ok:false,msg:'制水需要木板 ×1 作为燃料。'};
    const amount=p.tools.bottle?2:1;p.inventory.water=(p.inventory.water||0)+amount; return {ok:true,msg:`淡化完成，获得淡水 ×${amount}。`};
  }
  if(action==='cook'){
    if(!state.stations.grill) return {ok:false,msg:'先制作并放置简易烤架。'};
    if(invCount(p,'raw_fish')>0){p.inventory.raw_fish--;p.inventory.food=(p.inventory.food||0)+1;return {ok:true,msg:'鱼烤好了，获得熟食 ×1。'};}
    if(invCount(p,'potato')>0){p.inventory.potato--;p.inventory.food=(p.inventory.food||0)+1;return {ok:true,msg:'烤土豆做好了，获得熟食 ×1。'};}
    return {ok:false,msg:'需要生鱼或土豆。'};
  }
  if(action==='fish'){
    if(!p.tools.rod) return {ok:false,msg:'先制作钓鱼竿。'};
    const now=Date.now(); if(now-(p.lastFish||0)<5000) return {ok:false,msg:'等一会儿再收竿。'};
    p.lastFish=now; p.inventory.raw_fish=(p.inventory.raw_fish||0)+1; addEvent(`${p.name} 钓到了一条鱼`); return {ok:true,msg:'钓到生鱼 ×1，可以烤熟再吃。'};
  }
  if(action==='explore'){
    if(Math.hypot(p.x-state.island.x,p.y-state.island.y)>145) return {ok:false,msg:'游到右侧小岛附近再探索。注意水中有鲨鱼！'};
    const drops=[['plank',2],['leaf',2],['scrap',1],['potato',1]]; let [k,v]=drops[Math.floor(Math.random()*drops.length)]; if(p.tools.axe&&k==='plank')v++; p.inventory[k]=(p.inventory[k]||0)+v;
    if(Math.random()<0.22) p.inventory.stone=(p.inventory.stone||0)+1;
    addEvent(`${p.name} 在小岛上找到了一些物资`); return {ok:true,msg:`探索获得${itemNames[k]} ×${v}。`};
  }
  if(action==='repair'){
    const tile=state.raft.find(t=>!t.armored && t.hp<100);
    if(!tile) return {ok:false,msg:'目前没有需要修理的地板。'};
    if(!take(p,{plank:2})) return {ok:false,msg:'修理需要木板 ×2。'};
    tile.hp=100; return {ok:true,msg:'地板修理完成。'};
  }
  if(action==='armor'){
    const tile=state.raft.find(t=>!t.armored);
    if(!tile) return {ok:false,msg:'所有地板都已强化。'};
    if(!take(p,{scrap:4,plank:2})) return {ok:false,msg:'强化地板需要废料 ×4、木板 ×2。'};
    tile.armored=true; tile.hp=180; return {ok:true,msg:'一块地板已加装防护层，鲨鱼更难破坏它。'};
  }
  if(action==='revive'){
    const downed=Object.values(state.players).find(q=>q.id!==p.id&&q.down&&Math.hypot(q.x-p.x,q.y-p.y)<90);
    if(!downed) return {ok:false,msg:'靠近倒下的队友才能救援。'};
    if(!take(p,{food:1})) return {ok:false,msg:'救援需要一份熟食。'};
    downed.down=false; downed.hp=35; downed.hunger=Math.max(10,downed.hunger); downed.thirst=Math.max(10,downed.thirst); addEvent(`${p.name} 救起了队友 ${downed.name}`); return {ok:true,msg:`已救起 ${downed.name}。`};
  }
  if(action==='respawn'){
    p.down=false;p.hp=55;p.hunger=35;p.thirst=35;OceanMovement.reset(state,p);return {ok:true,msg:'你重新回到了木筏。'};
  }
  return {ok:false,msg:'暂不支持该操作。'};
}

function attachConnection(ws, req){
  if(playerCount()>=MAX_PLAYERS){ send(ws,{type:'full',message:'房间已满：最多两名玩家。'}); return ws.close(1008,'Room full'); }
  const url=new URL(req.url,'http://localhost');
  let name=(url.searchParams.get('name')||`漂流者${playerCount()+1}`).trim().slice(0,14).replace(/[<>]/g,'')||`漂流者${playerCount()+1}`;
  const id=randomUUID().slice(0,8);
  const colorsList=['#ffce74','#83e0d1'];
  const p={id,name,x:ORIGIN.x+(playerCount()===0?-20:20),y:ORIGIN.y,hp:100,hunger:100,thirst:100,down:false,
    altitude:.52,verticalVelocity:0,oxygen:100,yaw:0,moving:false,animTime:0,selectedSlot:0,inventory:{plank:8,plastic:5,leaf:5,scrap:3,stone:1,potato:1,raw_fish:0,food:2,water:2,metal:0,copper:0,seaweed:0},tools:{hook:1},color:colorsList[playerCount()],keys:{},lastSeen:Date.now(),lastFish:0};
  OceanMovement.normalize(state,p);OceanItems.slots(p);state.players[id]=p; ws.playerId=id;
  addEvent(`${name} 加入了漂流世界`); send(ws,{type:'welcome',id,name}); broadcast();
  ws.on('message',(raw)=>{
    let msg; try{msg=JSON.parse(raw.toString());}catch{return;}
    const player=state.players[ws.playerId]; if(!player) return;
    if(msg.type==='input'){
      const k=msg.keys||{}; player.keys={up:!!k.up,down:!!k.down,left:!!k.left,right:!!k.right,upward:!!k.upward,sprint:!!k.sprint,yaw:Number.isFinite(k.yaw)?k.yaw:(player.yaw||0),selectedSlot:Number.isFinite(k.selectedSlot)?Math.max(0,Math.min(9,Math.floor(k.selectedSlot))):(player.selectedSlot||0)}; player.yaw=player.keys.yaw; player.lastSeen=Date.now();
    } else if(msg.type==='action'){
      const result=doAction(player,String(msg.action||''),msg.data||{}); send(ws,{type:'result',...result}); broadcast();
    } else if(msg.type==='rename'){
      const n=String(msg.name||'').trim().slice(0,14).replace(/[<>]/g,''); if(n){player.name=n;addEvent(`${n} 更新了名字`);broadcast();}
    }
  });
  ws.on('close',()=>{const gone=state.players[ws.playerId]; if(gone){delete state.players[ws.playerId];addEvent(`${gone.name} 离开了世界`);broadcast();}});
}

let last=Date.now();
setInterval(()=>{
  const now=Date.now(); const dt=Math.min((now-last)/1000,.25); last=now;
  for(const p of Object.values(state.players)){
    if(!p.down){
      OceanMovement.step(state,p,p.keys,dt);
      p.hunger=clamp(p.hunger-.13*dt,0,100); p.thirst=clamp(p.thirst-.20*dt,0,100);
      if(p.hunger<=0||p.thirst<=0) p.hp=clamp(p.hp-2.8*dt,0,100);
      if(p.hp<=0){p.down=true;addEvent(`${p.name} 倒下了，队友可以靠近救援。`);}
      if(!isOnRaft(p)&&!isOnIsland(p)&&Math.hypot(p.x-state.shark.x,p.y-state.shark.y)<34){let damage=p.tools.armor?3.5:9;if(p.tools.spear)damage*=.7;p.hp=clamp(p.hp-damage*dt,0,100);state.shark.mood='追逐';}
    }
  }
  for(const r of state.resources){
    if(r.dropTool||r.dropItem)continue;const dx=ORIGIN.x-r.x,dy=ORIGIN.y-r.y,d=Math.hypot(dx,dy)||1;
    if(d>95){r.x+=dx/d*22*dt+Math.sin(now/700+r.phase)*3*dt; r.y+=dy/d*22*dt+Math.cos(now/900+r.phase)*3*dt;}
    else {r.x+=-dy/d*7*dt+Math.sin(now/700+r.phase)*2*dt; r.y+=dx/d*7*dt+Math.cos(now/900+r.phase)*2*dt;}
  }
  state.resources=state.resources.filter(r=>r.x>-80&&r.x<1040&&r.y>-80&&r.y<760);
  state.nextResource+=dt; if(state.nextResource>2.4 && state.resources.length<22){spawnDebris();state.nextResource=0;}
  state.netTimer-=dt; if(state.netTimer<=0 && state.stations.net>0){
    const nets=state.stations.net; const possible=Object.values(state.players);
    if(possible.length){const p=possible[Math.floor(Math.random()*possible.length)]; const type=['plank','plastic','leaf'][Math.floor(Math.random()*3)];p.inventory[type]=(p.inventory[type]||0)+nets;addEvent(`收集网自动捞到了${itemNames[type]} ×${nets}`);} state.netTimer=18;
  }
  state.sharkTimer-=dt;
  if(state.sharkTimer<=0){
    const candidates=state.raft.filter(t=>!t.armored); if(candidates.length){const tile=candidates[Math.floor(Math.random()*candidates.length)];tile.hp-=25;state.shark.x=ORIGIN.x+tile.gx*TILE+rand(-30,30);state.shark.y=ORIGIN.y+tile.gy*TILE+rand(-30,30);state.shark.mood='袭击木筏';addEvent('鲨鱼正在啃咬木筏地板！');if(tile.hp<=0){state.raft=state.raft.filter(t=>t!==tile);addEvent('一块木筏地板被鲨鱼破坏了！');}}
    else {state.shark.mood='巡游';}
    state.sharkTimer=35;
  }
  if(state.shark.mood!=='袭击木筏'){state.shark.x+=Math.sin(now/1800)*.8;state.shark.y+=Math.cos(now/1600)*.6;if(state.sharkTimer<28)state.shark.mood='巡游';}
  broadcast();
},100);

server.listen(PORT,'0.0.0.0',()=>console.log(`漂流纪元已启动：http://localhost:${PORT}`));
