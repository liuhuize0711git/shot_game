/* Shared inventory/hotbar transactions. The server owns these online. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.OceanItems=factory();})(globalThis,function(){
 'use strict';
 const defaults=['hook','spear','axe','rod','plank','stone','food','water','plastic','scrap'];
 const stations=['purifier','grill','net','sail','chest'];
 const toolKeys=['hook','spear','axe','rod','bottle','armor',...stations];
 const known=new Set([...defaults,...toolKeys,'leaf','potato','raw_fish','metal','copper','seaweed','glass']);
 function count(p,key){return key?Number(p.inventory?.[key]||0)+Number(p.tools?.[key]||0):0;}
 function slots(p){
  if(!p)return defaults;
  if(!Array.isArray(p.hotbar))p.hotbar=[...defaults];
  p.hotbar=Array.from({length:10},(_,i)=>known.has(p.hotbar[i])?p.hotbar[i]:null);
  p.selectedSlot=Number.isFinite(p.selectedSlot)?Math.max(0,Math.min(9,Math.floor(p.selectedSlot))):0;
  return p.hotbar;
 }
 function held(p){return slots(p)[p.selectedSlot||0];}
 function spawnDrop(w,key,amount,x,y,altitude=.44,options={}){
  if(!known.has(key)||!Number.isFinite(amount)||amount<1||![x,y,altitude].every(Number.isFinite))return null;
  const r={id:'drop_'+(typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'_'+Math.random().toString(36).slice(2)),type:key,amount:Math.floor(amount),x,y,altitude,phase:0,persistent:true,source:options.source||'player',dropTool:!!options.tool,dropItem:!options.tool};
  (w.resources||(w.resources=[])).push(r);return r;
 }
 function drop(w,p,key,amount=1){
  if(!known.has(key)||count(p,key)<amount||amount<1)return null;
  const tool=!!p.tools?.[key],bag=tool?p.tools:p.inventory;
  if(bag[key]<amount)return null;
  bag[key]-=amount;
  const yaw=Number.isFinite(p.yaw)?p.yaw:0;
  const altitude=p.motion==='RAFT_GROUNDED'?.8:p.motion==='ISLAND_GROUNDED'?p.altitude+.25:p.altitude<-.7?p.altitude+.35:.44;
  return spawnDrop(w,key,amount,p.x-Math.sin(yaw)*15,p.y-Math.cos(yaw)*15,altitude,{tool,source:'player'});
 }
 function equip(w,p,key){
  const bar=slots(p);if(!known.has(key)||count(p,key)<=0)return {ok:false};
  let index=bar.indexOf(key),dropped=null;
  if(index<0){
   index=bar.findIndex(k=>!k||count(p,k)===0);
   if(index<0){index=p.selectedSlot;const old=bar[index];if(old&&count(p,old))dropped=drop(w,p,old,count(p,old));}
   bar[index]=key;
  }
  p.selectedSlot=index;return {ok:true,dropped};
 }
 function craft(w,p,key,recipe){
  if(!known.has(key)||!recipe)return {ok:false,reason:'recipe'};
  if(Object.entries(recipe.cost).some(([k,v])=>(p.inventory[k]||0)<v))return {ok:false,reason:'materials'};
  for(const [k,v] of Object.entries(recipe.cost))p.inventory[k]-=v;
  p.tools[key]=(p.tools[key]||0)+1;
  return equip(w,p,key);
 }
 function collect(w,p,r,underwater=false){
  const list=underwater?w.underwaterResources:w.resources,index=list.indexOf(r);
  if(index<0)return false;
  list.splice(index,1);
  const amount=r.dropTool||r.dropItem?Math.max(1,Math.floor(r.amount||1)):underwater?(r.type==='seaweed'?2:1):['plank','leaf'].includes(r.type)?2:1;
  if(r.type==='barrel'){
   for(const [k,v] of Object.entries({plank:2,plastic:1,leaf:2,scrap:1}))p.inventory[k]=(p.inventory[k]||0)+v;
   if(Math.random()<.3)p.inventory.potato=(p.inventory.potato||0)+1;
  }else{const bag=r.dropTool?p.tools:p.inventory;bag[r.type]=(bag[r.type]||0)+amount;}
  if(r.dropTool)equip(w,p,r.type);
  else {
   // Picking up a first material makes an empty-handed start usable immediately;
   // ordinary pickups never evict a held stack from a full hotbar.
   const bar=slots(p),keys=r.type==='barrel'?['plank','plastic','leaf','scrap','potato']:[r.type];
   for(const key of keys){if(!known.has(key)||count(p,key)<=0||bar.includes(key))continue;const empty=bar.findIndex(k=>!k||count(p,k)===0);if(empty>=0)bar[empty]=key;}
   if(count(p,held(p))===0){const index=bar.findIndex(k=>count(p,k)>0);if(index>=0)p.selectedSlot=index;}
  }
  return true;
 }
 function place(w,p){const key=held(p);if(!stations.includes(key)||!p.tools[key]||p.motion!=='RAFT_GROUNDED')return false;p.tools[key]--;w.stations[key]=(w.stations[key]||0)+1;return true;}
 return {defaults,stations,toolKeys,count,slots,held,spawnDrop,drop,equip,craft,collect,place};
});
