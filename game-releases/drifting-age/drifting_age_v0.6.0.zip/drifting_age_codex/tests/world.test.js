'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const W=require('../public/world');
const M=require('../public/movement');
const T=require('../public/targeting');
const create=()=>W.ensure({raft:[],resources:[]});
const advance=(w,p,k,seconds)=>{for(let t=0;t<seconds;t+=1/60)M.step(w,p,k,1/60);};
function aim(w,p,t){
 const point=[(t.x-500)/30,W.shore(w,t.x,t.y).height+1,(t.y-350)/30];let best={score:Infinity};
 const initial=Math.atan2(p.x-t.x,p.y-t.y);
 for(let y=initial-.8;y<initial+.8;y+=.025)for(let pitch=-.5;pitch<=1.2;pitch+=.025){const view={yaw:y,pitch,dist:5.8,aspect:1.5},c=T.camera(w,p,view),s=T.project(c,point);if(!s)continue;const score=Math.hypot(s.x*c.aspect,s.y);if(score<best.score)best={score,view};}
 return best.view;
}
test('three different islands have supported landing, walking and shore departure',()=>{
 const w=create();assert.equal(w.islands.length,3);assert.equal(new Set(w.islands.map(i=>i.biome)).size,3);
 for(const i of w.islands){
  assert(W.terrain(i,i.x,i.y).height>=i.height);
  const p={x:i.x+i.rx*1.02,y:i.y,altitude:M.SURFACE,motion:'SURFACE_SWIM',hp:100,oxygen:100};
  advance(w,p,{left:true,upward:true},1.4);assert(M.onIsland(w,p),i.id+' auto landing');
  let last=p.altitude;
  for(let j=0;j<60;j++){M.step(w,p,{left:true},1/60);assert(Math.abs(p.altitude-last)<.1);last=p.altitude;}
  assert(M.onIsland(w,p));assert(Math.abs(p.altitude-W.shore(w,p.x,p.y).height)<1e-8);
  advance(w,p,{right:true},4);assert(!M.onIsland(w,p));
 }
});
test('all islands stop submerged penetration, shoreline requires surface approach',()=>{
 const w=create();for(const i of w.islands){const p={x:i.x+i.rx*1.02,y:i.y,altitude:-2,motion:'UNDERWATER',oxygen:100,hp:100};advance(w,p,{left:true},2);assert(W.shore(w,p.x,p.y).r>1);assert(!p.boarding);}
});
test('ecology has distinct island fauna and animals remain on their island',()=>{
 const w=create();const byIsland=w.islands.map(i=>w.animals.filter(a=>a.islandId===i.id).map(a=>a.species).sort().join(','));assert.equal(new Set(byIsland).size,3);
 for(const kind of ['goat','horse','boar','gull','parrot'])assert(w.animals.some(a=>a.species===kind));
 const before=JSON.stringify(w.animals);for(let n=0;n<50;n++)W.tick(w,.2,[]);assert.notEqual(JSON.stringify(w.animals),before);
 for(const a of w.animals){const i=w.islands.find(i=>i.id===a.islandId),ground=W.terrain(i,a.x,a.y);assert(ground.r<1);assert(a.altitude>=ground.height);}
});
test('axe aim/range checks, three-hit felling, permanent drops and timed renewable trees',()=>{
 const w=create(),t=w.trees[0];w.trees=[t];
 const p={x:t.x,y:t.y+50,motion:'ISLAND_GROUNDED',hp:100,tools:{axe:1},inventory:{},hotbar:['axe'],selectedSlot:0};p.altitude=W.shore(w,p.x,p.y).height;
 const view=aim(w,p,t),data={targetId:t.id,view};assert.equal(W.selectTree(w,p,view,T)?.id,t.id);
 assert.equal(W.chop(w,p,{...data,targetId:'wrong'},T).ok,false);assert.equal(t.hp,3);
 p.selectedSlot=1;assert.equal(W.chop(w,p,data,T).ok,false);p.selectedSlot=0;
 assert(W.chop(w,p,data,T).ok);assert.equal(t.hp,2);assert.equal(W.chop(w,p,data,T).ok,false);assert.equal(t.hp,2);
 W.tick(w,.5);assert(W.chop(w,p,data,T).ok);W.tick(w,.5);assert(W.chop(w,p,data,T).ok);assert.equal(t.hp,0);
 assert.deepEqual(w.resources.map(r=>[r.type,r.amount]),[['plank',4],['leaf',2]]);assert(w.resources.every(r=>r.persistent&&r.dropItem));
 assert.equal(W.chop(w,p,data,T).ok,false);assert.equal(w.resources.length,2);
 const positions=w.resources.map(r=>[r.x,r.y,r.altitude]);W.tick(w,179.9);assert.equal(t.hp,0);W.tick(w,.2);assert.equal(t.hp,3);assert.equal(w.resources.length,2);assert.deepEqual(w.resources.map(r=>[r.x,r.y,r.altitude]),positions);
 p.x+=300;assert.equal(W.chop(w,p,data,T).ok,false);
});
test('ecology save migration is idempotent and foraging requires actual land with cooldown',()=>{
 const w=create(),snapshot=JSON.stringify(w);W.ensure(w);assert.equal(JSON.stringify(w),snapshot);
 const restored=JSON.parse(snapshot);W.ensure(restored);assert.deepEqual(restored.trees,w.trees);
 const i=w.islands[1],p={x:i.x,y:i.y,motion:'SURFACE_SWIM',inventory:{}};assert(!W.explore(w,p).ok);
 p.motion='ISLAND_GROUNDED';assert(W.explore(w,p).ok);assert.equal(p.inventory.potato,1);assert(!W.explore(w,p).ok);W.tick(w,25);assert(W.explore(w,p).ok);assert.equal(p.inventory.potato,2);
});
