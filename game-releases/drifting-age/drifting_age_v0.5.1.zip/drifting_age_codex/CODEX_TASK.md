> 0.5.1 状态：下述 P0 修复已实现并完成自动化验收；详细证据和未做的真实设备测试见 QA_REPORT.md。以下保留原任务要求。

# Active Codex task — fix water navigation and boarding

Priority: P0. Start by reproducing both user-reported problems in the current 0.5.0 build. Do not claim the issues are fixed until the acceptance steps below have been run.

## User's latest feedback (preserve meaning)
1. Once the character enters the water, they cannot get back onto the raft or land on an island.
2. The character cannot sink quickly enough after entering the water. Desired rule: while in water, if Space is NOT held, the character gradually sinks; while Space IS held, the character gradually rises until reaching the water surface. This must be continuous motion, never an instant teleport.

## Required implementation
### A. Water movement state machine
Implement and document explicit states (names may differ):
- `RAFT_GROUNDED`: standing on a valid raft tile/deck.
- `ISLAND_GROUNDED`: standing on walkable island/shore terrain.
- `SURFACE_SWIM`: at the waterline, with horizontal swimming controls.
- `UNDERWATER`: below the waterline, with horizontal swim controls and gradual vertical movement.

Required behavior:
- Entering the water transitions smoothly from raft/island to surface swim and then underwater; no snapping to a distant altitude.
- While submerged, Space held means positive upward velocity until the water surface is reached. Space released means negative/downward velocity so the player sinks naturally. Use acceleration/velocity and clamp at sensible limits; do not directly assign surface altitude in one frame.
- At the waterline, clamp vertical position to the surface and keep the player in a stable surface-swimming state while horizontal movement/boarding is attempted. If the player is submerged and releases Space, sinking resumes. Do not make it impossible to board because the player sinks immediately at the surface; define a brief surface/boarding interaction window or equivalent explicit rule.
- WASD must remain functional in all water states. Movement should be camera-relative, smooth, and frame-rate independent.
- Preserve oxygen depletion underwater and recovery at the surface. Do not deplete oxygen while grounded.
- Camera and character animation must follow the current movement state and orientation.

### B. Raft collision and reboarding
Current behavior: the user gets into the water and cannot get back onto the raft. Fix the collision/boarding model, not just the UI.
- The raft is a solid walkable deck with a solid underside; the player cannot pass through the raft from below.
- The underside collision must not trap the player permanently. The player can swim horizontally out from under the raft, reach an outer edge, and board from the side.
- Provide a clear boarding action near a valid raft edge (prefer existing interaction key `E`; show a contextual hint). It should smoothly transition from surface swim to `RAFT_GROUNDED` and place the player on an actual walkable tile, without teleporting through the deck.
- Ensure the character cannot be grounded on a missing tile or walk through raft gaps. Handle all nine tiles of the initial 3×3 raft and any later expansions.
- Keep the existing 3×3 initial raft (9 tiles) and preserve expansion, repair and armor behavior.

### C. Island landing
- The player must be able to swim to a beach/shore and transition to `ISLAND_GROUNDED` at the shore edge.
- Use an explicit shore/beach collision/landing threshold; don't let the player walk on water or pass through the island surface.
- The player should be able to walk away from the shoreline on the island and return to the water.
- Add a contextual prompt/action if automatic beaching is unreliable. Reuse `E` if appropriate and avoid conflicting with resource collection.

### D. Multiplayer consistency
- Keep maximum 2 players.
- Both clients must see the same grounded/surface/underwater state and valid position transitions.
- Server authority/validation must not let the client bypass collision by sending an arbitrary altitude. If architecture currently trusts client movement, tighten only as much as needed and document the authority model.
- Disconnect/reconnect must not leave a ghost collision object or block boarding.

## Acceptance tests — all must be reported individually
1. Start a new single-player world. Confirm the raft has exactly 9 tiles.
2. Walk to a raft edge and enter the water. Confirm transition is smooth and the player does not teleport.
3. Submerged with Space released: depth increases gradually over multiple frames.
4. Hold Space while submerged: height increases gradually and stops at the waterline; no snap to deck height.
5. Swim horizontally out from under the raft, approach the outside edge, press E (or the chosen clearly documented interaction), and board. Confirm the player becomes grounded on the deck and can walk.
6. Attempt to swim upward directly under a raft tile. Confirm the solid underside blocks passage but does not trap the player; horizontal escape remains possible.
7. Swim to the island beach, land, walk on the island, and re-enter the water.
8. Confirm oxygen decreases underwater and recovers at the surface; no false depletion on land/raft.
9. Repeat steps 2–8 with two clients connected to the same server; both see consistent state and no player can appear through the raft.
10. Run static checks and browser tests; capture at least one real-WebGL screenshot of the scene and one screenshot of boarding/shore state.

## Regression requirements from earlier feedback
Keep and retest:
- Real 3D scene (not a 2D replacement), local procedural geometry, visible ocean/raft/island/player/resources.
- Third-person camera mouse look without holding the left mouse button; Esc releases pointer lock so settings can be used; left click remains available for weapon attack while looking around.
- Character faces camera/movement direction appropriately; walk/run/swim animations.
- 10-slot hotbar; `1`–`9`, `0` select slots; left/right arrows cycle; `T` drops held item and it can be picked up again.
- Settings for music/effects and remappable keys; conflicting key bindings are rejected without changing the existing binding.
- Surface/underwater transition and seabed mineral/seaweed resources.
- Single-player local save and maximum 2-player online co-op.

## Deliverables
- Implement the fixes in the current project; do not only write a plan.
- Update `README.md` with precise controls, including boarding action and swimming rules.
- Update `QA_REPORT.md` with test method/results and honest limitations.
- If any acceptance test cannot be run in the current environment, mark it BLOCKED/NOT RUN and explain how the user can verify it. Do not report it as passed.
