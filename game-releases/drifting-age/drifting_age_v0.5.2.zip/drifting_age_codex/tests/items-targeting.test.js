const {test}=require('node:test');const assert=require('node:assert/strict');
const I=require('../public/items'),T=require('../public/targeting'),M=require('../public/movement');
const world=()=>({raft:[],resources:[],underwaterResources:[],stations:{},island:{x:900,y:650,radius:80}});
const player=()=>({x:500,y:350,altitude:.52,motion:'RAFT_GROUNDED',selectedSlot:0,inventory:{plank:20,plastic:20,leaf:20,scrap:20,stone:1,food:1,water:1},tools:{hook:1,spear:1,axe:1,rod:1},oxygen:100});
test('full hotbar crafting drops entire held stack once and equips new product',()=>{
 const w=world(),p=player();p.selectedSlot=4;const before=p.inventory.plank;
 assert(I.craft(w,p,'bottle',{cost:{plastic:3}}).ok);assert.equal(I.held(p),'bottle');assert.equal(p.tools.bottle,1);assert.equal(p.inventory.plank,0);assert.equal(w.resources.length,1);assert.equal(w.resources[0].amount,before);
 const r=w.resources[0];I.collect(w,p,r);assert.equal(p.inventory.plank,before);assert.equal(w.resources.length,0);assert.equal(p.inventory.plastic,17);
});
test('empty slot, repeated recipe, failed recipe and stations preserve quantities',()=>{
 const w=world(),p=player();p.tools.spear=0;
 I.craft(w,p,'bottle',{cost:{plastic:3}});assert.equal(p.selectedSlot,1);assert.equal(I.held(p),'bottle');assert.equal(w.resources.length,0);
 I.craft(w,p,'bottle',{cost:{plastic:3}});assert.equal(p.tools.bottle,2);assert.equal(w.resources.length,0);
 const before=JSON.stringify(p);assert(!I.craft(w,p,'armor',{cost:{scrap:999}}).ok);assert.equal(JSON.stringify(p),before);
 I.craft(w,p,'purifier',{cost:{plank:6},station:true});assert.equal(I.held(p),'purifier');assert.equal(w.stations.purifier,undefined);assert(I.place(w,p));assert.equal(w.stations.purifier,1);assert.equal(p.tools.purifier,0);assert(!I.place(w,p));
});
test('old saves migrate and custom hotbar survives serialization',()=>{
 const w=world(),p=player();assert.equal(I.slots(p).length,10);I.craft(w,p,'armor',{cost:{scrap:5}});const saved=JSON.parse(JSON.stringify(p));assert.equal(I.held(saved),'armor');assert.equal(I.slots(saved).length,10);
 const drop=I.drop(w,saved,'armor');assert(drop.dropTool);assert.equal(drop.altitude,.8);assert(I.collect(w,saved,drop));assert.equal(I.held(saved),'armor');assert.equal(saved.tools.armor,1);
});
test('aim circle selects centred target rather than closer off-axis debris; rejects no id, stale and distant ids',()=>{
 const w=world(),p=player(),view={yaw:0,pitch:.42,dist:9.2,aspect:1.5};
 w.resources=[{id:'aimed',type:'plank',x:526,y:285,altitude:.44},{id:'closer',type:'plastic',x:460,y:340,altitude:.44}];
 assert.equal(T.select(w,p,view).resource.id,'aimed');assert.equal(T.validate(w,p,{targetId:'closer',view}),null);assert.equal(T.validate(w,p,{}),null);
 assert(T.validate(w,p,{targetId:'aimed',view}));w.resources[0].y=100;assert.equal(T.validate(w,p,{targetId:'aimed',view}),null);
});
test('no targeting behind the camera or through a raft deck',()=>{
 const w=world(),p=player();w.resources=[{id:'behind',type:'plank',x:500,y:650}];assert.equal(T.select(w,p,{yaw:0}),null);
 w.raft=[{gx:0,gy:0}];assert(T.occluded(w,[0,3,0],[0,-2,0]));assert(!T.occluded(w,[3,3,0],[3,-2,0]));
});
test('two players cannot duplicate the same world drop',()=>{
 const w=world(),a=player(),b=player();const r=I.drop(w,a,'plank',5);assert(I.collect(w,b,r));assert(!I.collect(w,a,r));assert.equal(a.inventory.plank,15);assert.equal(b.inventory.plank,25);
});
