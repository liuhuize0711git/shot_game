# Codex project instructions — 漂流纪元

## Start here
1. Read `CODEX_TASK.md` for the active tasks and acceptance criteria.
2. Read `CONVERSATION_HISTORY.md` for user intent and version history.
3. Read `README.md` and `QA_REPORT.md` before changing code.
4. Treat the source in this folder as the current baseline. `reference_versions/` is archival only; do not edit it.

## Project constraints
- Product: original browser-based 3D ocean survival prototype, Chinese UI, single-player plus at most two online players.
- Current version baseline: 0.5.2. Automatic exterior boarding, mouse re-lock, dynamic crafting/equipment and centre-circle targeting are implemented; see QA_REPORT.md for verified acceptance and remaining limits.
- Server: Node.js 18+, `server.js`; serves `public/index.html` and handles WebSocket sync without third-party runtime dependencies.
- Client: plain JavaScript and WebGL 1 in `public/index.html`. Keep the app runnable with `npm start` and `http://localhost:3000`.
- Do not replace the 3D game with a 2D/canvas pseudo-3D fallback. Preserve actual 3D geometry and test on a browser with WebGL enabled.
- Keep all core models local/procedural unless the project deliberately adds licensed local assets. Do not introduce external runtime CDNs or require external model downloads.
- Keep single-player playable offline and preserve max 2-player multiplayer.
- Use original game names, models, UI, sounds, and story. The goal is an original survival game inspired by genre mechanics, not copying proprietary source/assets.

## Engineering and QA rules
- First reproduce and understand the current issue before patching. Prefer focused fixes over a broad rewrite.
- Add/adjust explicit state transitions and collision tests; avoid teleporting the player to solve movement issues.
- Run `node --check server.js`.
- Extract the inline client JavaScript from `public/index.html` and run `node --check` on it.
- Start the server and check HTTP 200. Test WebSocket capacity/sync if changing networking.
- For visual claims, use a real browser with a real WebGL context and capture screenshots. A no-op WebGL mock can test UI logic but does NOT count as visual rendering verification.
- Never mark a test as passed unless it was actually executed. Clearly separate automated logic tests from manual/GPU/browser visual checks.
- Update `QA_REPORT.md` with commands, test conditions, actual results, and remaining limitations.

## Completed-version archives (user requirement)
After each completed game modification, first save a complete runnable versioned ZIP under `/workspace/shot_game/game-releases/drifting-age/`, separate from the original game files. Preserve earlier archives, verify ZIP integrity, and update that directory's README index and SHA-256. The user explicitly authorizes committing and pushing each completed archive and its release documentation to the `main` branch of GitHub repository `liuhuize0711git/shot_game`. Commit only the release files; do not include unrelated changes or force push. Verify the remote commit and provide a GitHub download link. If upload fails, report that it remains local. Follow the release directory's AGENTS.md.
