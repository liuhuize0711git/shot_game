请先读取 AGENTS.md、CODEX_TASK.md、README.md 和 QA_REPORT.md。当前版本为 0.5.2，外沿自动登筏、Esc 后恢复视角、满栏制作换手和圆区定向拾取已实现。后续根据玩家最新反馈继续改进；每次修改完成后按 AGENTS.md 的规则验收，并把完整版本压缩包提交、推送到 GitHub 独立发布目录，保留历史版本。
