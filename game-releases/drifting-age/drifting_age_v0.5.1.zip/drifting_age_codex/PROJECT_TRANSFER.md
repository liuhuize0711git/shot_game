> 更新：当前目录已推进至 0.5.1，水中移动、登筏和登陆修复与测试结果见 README.md、QA_REPORT.md。下面保留最初交接步骤。

# 如何将项目交给 Codex 继续开发

1. 下载并解压 `drifting_age_codex_handoff.zip`。
2. 在 Codex 中新建/打开本地项目，选择解压后的 `drifting_age_codex` 文件夹（文件夹内直接有 `package.json`、`server.js`、`public/`）。
3. 让 Codex 先阅读 `AGENTS.md`、`CODEX_TASK.md`、`CONVERSATION_HISTORY.md`、`README.md` 和 `QA_REPORT.md`。
4. 在 Codex 的任务输入框粘贴 `CODEX_PROMPT.md` 的内容。首要任务是修复落水后无法重新登筏/登陆，以及 Space 上浮、松开 Space 下沉的连续水中运动。
5. 在项目终端运行 `npm start`，浏览器访问 `http://localhost:3000`。Node.js 版本要求 18 或更新。
6. Codex 修改代码后，要求它更新 `QA_REPORT.md`，并使用支持 WebGL 的真实浏览器截图验证；不要把只跑过静态检查或 no-op WebGL mock 当作 3D 画面验收。

## 重要说明

当前聊天无法直接创建、切换或写入用户的 Codex 项目空间，也不能在没有用户授权的情况下推送到 GitHub。这个包是可以导入/打开的项目交接包：包含当前 v0.5.0 游戏源代码、启动配置、测试报告、历史需求摘要、用户关键消息原文、Codex 指令和 v0.4 历史快照。打开文件夹后即可让 Codex 接手。
