/* Original rounded cartoon survivor. Primitive dimensions are full diameters. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.OceanAvatar=factory();})(globalThis,function(){
 'use strict';
 function drawAvatar(p,idx,ctx){
  const {draw,meshes,C,elapsed,camYaw,wpos,playerBaseY,isDiving,isSurfaceSwimming,hexRgb,hotbarSlots}=ctx;
  const w=wpos(p),yaw=Number.isFinite(p.yaw)?p.yaw:camYaw,base=playerBaseY(p)-.12;
  const diving=isDiving(p),swimming=diving||isSurfaceSwimming(p),moving=!!p.moving,phase=p.animTime||0;
  const running=moving&&!swimming&&!!p.sprinting,breath=Math.sin(elapsed*1.8+idx)*.007;
  const gait=moving?Math.sin(phase)*(running?.75:.48):0;
  const bob=swimming?Math.sin(phase*2)*.025:moving?Math.abs(Math.sin(phase))*(running?.045:.022):breath;
  const pitch=p.down?-1.5:diving?-1.35:swimming?-.90:0;
  const shirt=p.color?hexRgb(p.color):(idx?C.blue:C.shirt),skin=idx?[.73,.46,.30]:[.95,.69,.48];
  const hair=idx?[.16,.10,.075]:[.23,.12,.065],shorts=[.12,.28,.36],shoe=[.35,.22,.13],blush=[.93,.49,.37],ivory=[1,.96,.86];
  function pos(x,y,z){const yy=y*Math.cos(pitch)-z*Math.sin(pitch),zz=y*Math.sin(pitch)+z*Math.cos(pitch);return [w.x+x*Math.cos(yaw)+zz*Math.sin(yaw),base+yy+bob,w.z-x*Math.sin(yaw)+zz*Math.cos(yaw)];}
  function part(mesh,x,y,z,sx,sy,sz,color,rx=0,rz=0){const q=pos(x,y,z);draw(mesh,...q,sx,sy,sz,color,yaw,false,rx+pitch,rz);}
  function oval(x,y,z,sx,sy,sz,color,rx=0,rz=0){part(meshes.sphere,x,y,z,sx,sy,sz,color,rx,rz);}
  function limb(x,y,z,length,width,angle,color){const end={x,y:y-Math.cos(angle)*length,z:z+Math.sin(angle)*length};oval(x,(y+end.y)/2,(z+end.z)/2,width,length+width*.40,width*.92,color,angle);return end;}
  // A continuous clothed silhouette: broad T-shirt, soft shorts, bare lower legs.
  oval(0,.94,0,.53,.44,.32,shirt);
  oval(0,1.18,0,.61,.45,.36,shirt);
  oval(0,1.32,0,.54,.22,.34,shirt);
  oval(0,.77,0,.50,.28,.33,shorts);
  oval(0,1.41,0,.19,.23,.19,skin);
  oval(0,1.36,-.01,.26,.055,.23,ivory);
  // Small original sea-wave shirt badge.
  oval(-.14,1.19,-.181,.11,.075,.014,ivory,0,-.25);
  oval(-.105,1.205,-.186,.045,.037,.014,shirt);
  // Large face, connected ears, a swept hairline and visible eyes.
  oval(0,1.70,-.01,.57,.62,.51,skin);
  oval(0,1.56,-.055,.43,.28,.43,skin);
  oval(-.28,1.69,.015,.11,.16,.10,skin);oval(.28,1.69,.015,.11,.16,.10,skin);
  oval(-.30,1.69,-.028,.042,.083,.018,blush);oval(.30,1.69,-.028,.042,.083,.018,blush);
  oval(0,1.90,.045,.59,.28,.51,hair);
  oval(0,1.76,.19,.52,.38,.19,hair);
  oval(-.245,1.78,.015,.10,.24,.21,hair,0,-.15);
  oval(.245,1.81,.02,.10,.20,.20,hair,0,.15);
  oval(-.14,1.91,-.17,.25,.17,.23,hair,0,-.30);
  oval(.04,1.94,-.15,.26,.16,.23,hair,0,.25);
  oval(.18,1.91,-.14,.17,.13,.20,hair,0,.45);
  for(const side of [-1,1]){
   oval(side*.112,1.725,-.239,.125,.135,.051,ivory);
   oval(side*.112,1.719,-.264,.060,.083,.025,[.15,.27,.29]);
   oval(side*.112,1.716,-.277,.032,.058,.014,[.055,.065,.07]);
   oval(side*.112-.012,1.741,-.284,.018,.020,.010,[1,1,1]);
   oval(side*.112,1.811,-.235,.126,.026,.028,hair,0,side*.12);
   oval(side*.175,1.615,-.225,.080,.040,.017,blush,0,side*.10);
  }
  oval(0,1.65,-.267,.087,.105,.093,skin);
  oval(0,1.562,-.253,.116,.045,.019,[.48,.22,.16]);
  oval(0,1.576,-.261,.087,.021,.012,ivory);
  // Shoulders and sleeves connect directly to arms; no exposed ball joints.
  const key=hotbarSlots(p)[Number(p.selectedSlot)||0],hasHeld=!!key&&((p.tools?.[key]||0)+(p.inventory?.[key]||0)>0);
  let rightHand;
  for(const side of [-1,1]){
   const angle=swimming?Math.sin(phase*1.55+(side>0?Math.PI:0))*.90:side*gait;
   const upperAngle=hasHeld&&side>0&&!swimming?.18:angle;
   const foreAngle=hasHeld&&side>0&&!swimming?1.05:swimming?angle*.8+.25:angle*.6+.12;
   const x=side*.34;oval(x,1.26,0,.255,.28,.29,shirt,upperAngle,side*.10);
   const elbow=limb(x,1.23,.01,.26,.18,upperAngle,skin);
   const hand=limb(x,elbow.y,elbow.z,.25,.145,foreAngle,skin);
   oval(x,hand.y-.025,hand.z,.14,.17,.12,skin,foreAngle);
   oval(x-side*.065,hand.y+.005,hand.z-.025,.063,.095,.065,skin,foreAngle,.25*side);
   // Joined fingers give a rounded hand rather than a clamp.
   oval(x,hand.y-.080,hand.z+.008,.118,.058,.105,skin,foreAngle);
   if(side>0)rightHand={x,y:hand.y-.02,z:hand.z};
   const hipAngle=swimming?Math.sin(phase*2.0+(side>0?Math.PI:0))*.48:-side*gait;
   const knee=limb(side*.145,.73,0,.31,.225,hipAngle,shorts);
   const calfAngle=swimming?hipAngle*.7:Math.max(0,-hipAngle)*.60;
   const ankle=limb(side*.145,knee.y,knee.z,.29,.15,calfAngle,skin);
   oval(side*.145,ankle.y-.025,ankle.z-.035,.20,.13,.30,shoe,calfAngle*.35);
   oval(side*.145,ankle.y-.075,ankle.z-.045,.21,.035,.31,ivory,calfAngle*.35);
  }
  // Props follow the actual right hand. Empty starts have no phantom equipment.
  if(hasHeld&&rightHand){
   const {x,y,z}=rightHand;
   if(['hook','spear','axe','rod'].includes(key)){
    part(meshes.cylinder,x,y+.14,z,.052,.68,.052,C.woodLight,.12);
    if(key==='axe'){part(meshes.cube,x+.10,y+.41,z-.04,.29,.17,.10,C.metal,.12);}
    else if(key==='spear')part(meshes.cone,x,y+.55,z-.035,.12,.29,.12,C.metal,.12);
    else if(key==='hook'){oval(x+.04,y+.50,z-.04,.15,.17,.09,C.metal);oval(x+.065,y+.52,z-.09,.075,.10,.065,shirt);}
    else{part(meshes.cylinder,x,y+.62,z-.06,.024,.40,.024,C.wood2,.2);oval(x,y+.17,z-.06,.11,.10,.06,C.metal);}
   }else if(['water','bottle'].includes(key)){part(meshes.cylinder,x,y+.10,z-.03,.15,.28,.15,C.plastic);part(meshes.cylinder,x,y+.265,z-.03,.075,.06,.075,C.white);}
   else if(key==='plank'){part(meshes.cube,x,y+.08,z-.02,.16,.50,.07,C.woodLight,.2);}
   else{const col=['purifier','grill','net','sail','chest'].includes(key)?C.wood2:key==='scrap'?C.metal:key==='plastic'?C.plastic:key==='stone'?C.rock:key==='food'?C.orange:C.leaf;part(meshes.cube,x,y+.06,z-.035,.22,.20,.20,col,.12);}
  }
 }
 return {draw:drawAvatar};
});
