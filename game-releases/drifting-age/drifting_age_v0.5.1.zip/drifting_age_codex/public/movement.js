/* Shared deterministic movement. Positions x/y use map units (30 per metre),
 * altitude/velocity use metres. Online players submit controls, never positions. */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.OceanMovement=factory();
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DECK=.52,SURFACE=-.34,UNDERSIDE=-.72,BOTTOM=-7.25;
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const tileAt=(w,x,y)=>w.raft.find(t=>Math.abs(x-(500+t.gx*48))<24&&Math.abs(y-(350+t.gy*48))<24);
  const overRaft=(w,p)=>!!tileAt(w,p.x,p.y);
  // The sand ellipsoid and raised grass match the local procedural island meshes.
  function shore(w,x,y){
    const i=w.island;if(!i)return {r:Infinity,height:0};
    const dx=(x-i.x)/30,dz=(y-i.y)/30,radius=i.radius/30;
    const r=Math.hypot(dx/(radius*1.18),dz/(radius*.92));
    let height=.08+.46*Math.sqrt(Math.max(0,1-r*r));
    const a=Math.atan2(dz/(radius*.70),dx/(radius*.88));
    const edge=1+.045*Math.sin(a*3)+.035*Math.cos(a*5);
    const g=Math.hypot(dx/(radius*.88),dz/(radius*.70))/edge;
    if(g<=1)height=Math.max(height,.038+.58*Math.pow(1-g,1.45)+.025*Math.sin(a*4+g*4)*g);
    for(const m of [{x:-.8,z:.3,rx:1.1,rz:.8,y:.52,h:.5},{x:1.25,z:-.5,rx:.75,rz:.62,y:.45,h:.36}]){
      const q=Math.hypot((dx-m.x)/m.rx,(dz-m.z)/m.rz);
      if(q<1)height=Math.max(height,m.y+m.h*Math.sqrt(1-q*q));
    }
    return {r,height};
  }
  function normalize(w,p){
    if(!Number.isFinite(p.altitude))p.altitude=DECK;
    if(!Number.isFinite(p.verticalVelocity))p.verticalVelocity=0;
    if(!p.motion){
      if(overRaft(w,p)&&p.altitude>=.4)p.motion='RAFT_GROUNDED';
      else if(shore(w,p.x,p.y).r<=1&&p.altitude>=0)p.motion='ISLAND_GROUNDED';
      else p.motion=p.altitude>SURFACE?'FALLING':p.altitude>=SURFACE-.02?'SURFACE_SWIM':'UNDERWATER';
    }
  }
  function onRaft(w,p){return p.motion==='RAFT_GROUNDED'&&overRaft(w,p);}
  function onIsland(w,p){return p.motion==='ISLAND_GROUNDED'&&shore(w,p.x,p.y).r<=1;}
  function diving(w,p){return !onRaft(w,p)&&!onIsland(w,p)&&p.motion!=='BOARDING'&&(p.altitude<-1.05||(p.altitude<0&&overRaft(w,p)));}
  function boardingTarget(w,p){
    if(p.down||p.boarding||p.altitude<SURFACE-.12||p.altitude>SURFACE+.1||overRaft(w,p))return null;
    let best=null;
    for(const t of w.raft)for(const [nx,ny] of [[1,0],[-1,0],[0,1],[0,-1]]){
      if(w.raft.some(n=>n.gx===t.gx+nx&&n.gy===t.gy+ny))continue;
      const cx=500+t.gx*48,cy=350+t.gy*48;
      const outside=(p.x-cx)*nx+(p.y-cy)*ny;
      const tangent=(p.x-cx)*(-ny)+(p.y-cy)*nx;
      // Only exposed side faces, away from corners: never climb through a tile.
      if(outside<24||outside>44||Math.abs(tangent)>18)continue;
      const x=cx+nx*14-ny*tangent,y=cy+ny*14+nx*tangent;
      if(!best||outside<best.distance)best={kind:'raft',gx:t.gx,gy:t.gy,x,y,height:DECK,distance:outside};
    }
    const s=shore(w,p.x,p.y);
    if(!best&&s.r>1&&s.r<1.16){
      const i=w.island,scale=.94/s.r,x=i.x+(p.x-i.x)*scale,y=i.y+(p.y-i.y)*scale;
      best={kind:'island',x,y,height:shore(w,x,y).height};
    }
    return best;
  }
  function interact(w,p){
    normalize(w,p);const t=boardingTarget(w,p);if(!t)return false;
    p.boarding={...t,startX:p.x,startY:p.y,startAltitude:p.altitude,time:0};
    p.motion='BOARDING';p.verticalVelocity=0;return true;
  }
  function finishVitals(w,p,dt){
    p.oxygen=clamp((p.oxygen??100)+(diving(w,p)?-8.5:16)*dt,0,100);
    if(p.oxygen===0)p.hp=clamp((p.hp??100)-5*dt,0,100);
    p.surfaceSwimming=p.motion==='SURFACE_SWIM';
    p.onRaft=onRaft(w,p);p.onIsland=onIsland(w,p);
  }
  function substep(w,p,k,dt){
    normalize(w,p);
    if(p.boarding){
      const b=p.boarding;
      const valid=b.kind==='raft'?w.raft.some(t=>t.gx===b.gx&&t.gy===b.gy):shore(w,b.x,b.y).r<=1;
      if(!valid){delete p.boarding;p.motion='FALLING';}
      else{
        b.time+=dt;const t=clamp(b.time/1.2,0,1),lift=Math.min(t/.55,1);
        const travel=clamp((t-.55)/.45,0,1),smooth=travel*travel*(3-2*travel),top=Math.max(.65,b.height+.12);
        p.x=b.startX+(b.x-b.startX)*smooth;p.y=b.startY+(b.y-b.startY)*smooth;
        p.altitude=t<.55?b.startAltitude+(top-b.startAltitude)*lift:top+(b.height-top)*smooth;
        p.moving=true;p.sprinting=false;p.animTime=(p.animTime||0)+dt*5;
        if(t===1){p.motion=b.kind==='raft'?'RAFT_GROUNDED':'ISLAND_GROUNDED';delete p.boarding;}
        finishVitals(w,p,dt);return;
      }
    }
    const grounded=onRaft(w,p)||onIsland(w,p),water=!grounded&&p.altitude<=SURFACE+.01;
    const f=(k.up?1:0)-(k.down?1:0),s=(k.right?1:0)-(k.left?1:0),len=Math.hypot(f,s),yaw=Number.isFinite(k.yaw)?k.yaw:0;
    const speed=(grounded?(onRaft(w,p)?142:96):(diving(w,p)?56:82))*(k.sprint&&grounded?1.55:1);
    let dx=0,dy=0;
    if(len){dx=(s*Math.cos(yaw)-f*Math.sin(yaw))/len;dy=(-s*Math.sin(yaw)-f*Math.cos(yaw))/len;}
    // Axis sliding keeps horizontal escape possible under tiles and along shore.
    for(const axis of ['x','y']){
      const next={...p,[axis]:clamp(p[axis]+(axis==='x'?dx:dy)*speed*dt,12,axis==='x'?988:688)};
      const hitsDeck=!grounded&&p.altitude>UNDERSIDE+.001&&p.altitude<DECK-.01&&overRaft(w,next);
      const hitsIsland=!onIsland(w,p)&&shore(w,next.x,next.y).r<=1&&p.altitude<shore(w,next.x,next.y).height-.08;
      if(!hitsDeck&&!hitsIsland)p[axis]=next[axis];
    }
    p.moving=!!len;p.sprinting=!!k.sprint&&grounded;
    p.yaw=len?Math.atan2(-dx,-dy):yaw;p.animTime=(p.animTime||0)+dt*(len?(water?7.5:p.sprinting?13.5:8.5):1.5);
    if(onRaft(w,p)){p.altitude=DECK;p.verticalVelocity=0;}
    else if(onIsland(w,p)){p.altitude=shore(w,p.x,p.y).height;p.verticalVelocity=0;}
    else{
      if(grounded){p.motion='FALLING';p.verticalVelocity=0;}
      let alt=p.altitude,vy=p.verticalVelocity;
      if(alt>SURFACE){
        vy-=2.6*dt;const next=alt+vy*dt;
        // Catch a falling player only from above an actual support.
        const floor=overRaft(w,p)?DECK:shore(w,p.x,p.y).r<=1?shore(w,p.x,p.y).height:null;
        if(floor!==null&&alt>=floor&&next<=floor){alt=floor;vy=0;p.motion=overRaft(w,p)?'RAFT_GROUNDED':'ISLAND_GROUNDED';}
        else if(next<=SURFACE){alt=SURFACE;vy=0;p.surfaceGrace=.85;p.motion='SURFACE_SWIM';}
        else{alt=next;p.motion='FALLING';}
      }else{
        const ceiling=overRaft(w,p)?UNDERSIDE:SURFACE;
        if(alt>=SURFACE-.001&&!overRaft(w,p)&&(k.upward||(p.surfaceGrace||0)>0)){
          alt=SURFACE;vy=0;p.motion='SURFACE_SWIM';p.surfaceGrace=k.upward?.85:Math.max(0,(p.surfaceGrace||0)-dt);
        }else{
          vy=clamp(vy+(k.upward?2.8:-1.6)*dt,-1.35,1.4);
          const next=alt+vy*dt;
          if(next>=ceiling&&vy>0){alt=ceiling;vy=0;if(ceiling===SURFACE)p.surfaceGrace=.85;}
          else alt=Math.max(BOTTOM,next);
          if(alt===BOTTOM&&vy<0)vy=0;
          p.motion=alt>=SURFACE-.001?'SURFACE_SWIM':'UNDERWATER';
        }
      }
      p.altitude=alt;p.verticalVelocity=vy;
    }
    finishVitals(w,p,dt);
  }
  function step(w,p,k,dt){
    if(p.down||!Number.isFinite(dt)||dt<=0)return;
    // Both the 10 Hz authority and high-refresh clients use identical small steps.
    let remaining=Math.min(dt,.25);
    while(remaining>1e-8){const h=Math.min(remaining,1/120);substep(w,p,k||{},h);remaining-=h;}
  }
  function reset(w,p){
    delete p.boarding;delete p.motion;p.surfaceGrace=0;p.verticalVelocity=0;
    const t=w.raft[0];
    if(t){p.x=500+t.gx*48;p.y=350+t.gy*48;p.altitude=DECK;}
    else{p.x=500;p.y=350;p.altitude=SURFACE;}
    normalize(w,p);
  }
  return {step,interact,boardingTarget,overRaft,onRaft,onIsland,diving,shore,normalize,reset,DECK,SURFACE,UNDERSIDE};
});
