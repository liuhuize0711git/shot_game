/* Original local island ecology; shared by browser simulation and Node authority. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.OceanWorld=factory();})(globalThis,function(){
 'use strict';
 const TREE_REGROW_SECONDS=180;
 const speciesNames={goat:'山羊',horse:'野马',boar:'野猪',gull:'海鸥',parrot:'鹦鹉'};
 const treeNames={palm:'棕榈树',broadleaf:'阔叶树',pine:'松树'};
 const presets=[
  {id:'palm-cove',name:'棕榈沙洲',biome:'palm',x:740,y:290,radius:120,rx:142,rz:110,height:.85,seed:1.2},
  {id:'green-meadow',name:'青岚草甸岛',biome:'meadow',x:-140,y:650,radius:220,rx:230,rz:180,height:1.9,seed:2.6},
  {id:'pine-ridge',name:'松风高地岛',biome:'ridge',x:1190,y:950,radius:280,rx:285,rz:220,height:3,seed:4.2}
 ];
 function terrain(i,x,y){
  const dx=(x-i.x)/(i.rx||i.radius*1.18),dy=(y-i.y)/(i.rz||i.radius*.92),r=Math.hypot(dx,dy),a=Math.atan2(dy,dx);
  if(r>1)return {r,height:.035-(r-1)*4,island:i};
  const h=i.height??.85,base=1-r;
  return {r,height:.035+h*Math.pow(base,1.45)+h*.17*base*Math.sin(3*a+(i.seed||0))*Math.sin(r*Math.PI),island:i};
 }
 function shore(w,x,y){
  let best={r:Infinity,height:0,island:null};
  for(const i of w.islands||[]){const t=terrain(i,x,y);if(t.r<best.r)best=t;}
  return best;
 }
 function createTrees(islands){
  const trees=[];
  for(const i of islands){const n=i.biome==='palm'?4:i.biome==='meadow'?7:9;
   for(let k=0;k<n;k++){const a=k*2.399+i.seed,r=.31+(k%3)*.16;
    trees.push({id:i.id+'_tree_'+k,islandId:i.id,x:i.x+Math.cos(a)*i.rx*r,y:i.y+Math.sin(a)*i.rz*r,kind:i.biome==='palm'?'palm':i.biome==='ridge'?'pine':'broadleaf',hp:3,regrowAt:0});
   }
  }return trees;
 }
 function createAnimals(islands){
  const animals=[];
  for(const i of islands){const kinds=i.biome==='palm'?['gull','parrot']:i.biome==='meadow'?['goat','horse','gull','goat']:['boar','goat','boar','parrot','gull'];
   kinds.forEach((species,k)=>{const phase=k*2.1+i.seed;animals.push({id:i.id+'_animal_'+k,islandId:i.id,species,x:i.x+Math.cos(phase)*i.rx*.5,y:i.y+Math.sin(phase)*i.rz*.5,yaw:phase,phase,altitude:0});});
  }return animals;
 }
 function ensure(w){
  if(!Array.isArray(w.islands)||!w.islands.length){w.islands=presets.map(i=>({...i}));if(w.island){Object.assign(w.islands[0],{x:w.island.x,y:w.island.y});}}
  w.island=w.islands[0];
  if(!Array.isArray(w.trees))w.trees=createTrees(w.islands);
  if(!Array.isArray(w.animals))w.animals=createAnimals(w.islands);
  if(!Number.isFinite(w.worldClock))w.worldClock=0;
  if(!Array.isArray(w.resources))w.resources=[];
  w.bounds={minX:-800,maxX:1900,minY:-600,maxY:1700};
  return w;
 }
 function tick(w,dt,players=[]){
  if(!Number.isFinite(dt)||dt<=0)return;ensure(w);w.worldClock+=dt;
  for(const t of w.trees)if(t.hp<=0&&w.worldClock>=(t.regrowAt||Infinity)){t.hp=3;t.regrowAt=0;}
  for(const a of w.animals){
   const i=w.islands.find(i=>i.id===a.islandId);if(!i)continue;
   const bird=a.species==='gull'||a.species==='parrot';
   const phase=a.phase+w.worldClock*(bird?.22:.075),radius=bird?.63:a.species==='horse'?.55:.43;
   let tx=i.x+Math.cos(phase)*i.rx*radius,ty=i.y+Math.sin(phase*.83)*i.rz*radius;
   if(a.species==='boar'){
    const p=players.find(p=>!p.down&&p.motion==='ISLAND_GROUNDED'&&Math.hypot(p.x-a.x,p.y-a.y)<95);
    if(p){tx=p.x;ty=p.y;const distance=Math.hypot(tx-a.x,ty-a.y);if(distance<15)p.hp=Math.max(0,(p.hp??100)-5*dt);}
   }
   const dx=tx-a.x,dy=ty-a.y,d=Math.hypot(dx,dy),speed=bird?34:a.species==='horse'?24:a.species==='boar'?28:18;
   if(d>.01){const step=Math.min(d,speed*dt);a.x+=dx/d*step;a.y+=dy/d*step;a.yaw=Math.atan2(-dx,-dy);}
   const t=terrain(i,a.x,a.y);a.altitude=t.height+(bird?2.2+Math.sin(phase*1.4)*.4:0);
  }
 }
 function selectTree(w,p,view,T){
  if(!p||p.down||p.boarding||p.motion!=='ISLAND_GROUNDED'||!T)return null;
  const c=T.camera(w,p,view);let best=null;
  for(const tree of w.trees||[]){
   if(tree.hp<=0||Math.hypot(tree.x-p.x,tree.y-p.y)>84)continue;
   const base=shore(w,tree.x,tree.y).height,point=[(tree.x-500)/30,base+1,(tree.y-350)/30],screen=T.project(c,point);
   if(!screen)continue;const offset=Math.hypot(screen.x*c.aspect,screen.y);
   if(offset>.14||T.occluded(w,c.eye,point))continue;
   if(!best||offset<best.offset)best={tree,id:tree.id,name:treeNames[tree.kind]||'树木',point,offset,screen};
  }return best;
 }
 function chop(w,p,data,T){
  if(!p.tools?.axe||p.hotbar?.[p.selectedSlot||0]!=='axe')return {ok:false,msg:'先制作并手持斧头，再瞄准树干砍伐。'};
  const target=selectTree(w,p,data?.view,T);
  if(!target||target.id!==data?.targetId)return {ok:false,msg:'靠近岛上的树，瞄准树干后再砍伐。'};
  if(w.worldClock-(p.lastChop??-100)<.45)return {ok:false,msg:'挥斧中…'};
  p.lastChop=w.worldClock;const t=target.tree;t.hp--;
  if(t.hp>0)return {ok:true,msg:`${target.name}：还需砍伐 ${t.hp} 次。`};
  t.regrowAt=w.worldClock+TREE_REGROW_SECONDS;
  const ground=shore(w,t.x,t.y).height;
  for(const [type,amount,dx] of [['plank',4,-12],['leaf',2,12]])w.resources.push({id:t.id+'_'+type+'_'+w.worldClock.toFixed(3),type,amount,x:t.x+dx,y:t.y,altitude:ground+.3,phase:0,dropItem:true,persistent:true,origin:'tree',source:'tree'});
  return {ok:true,msg:'树木已砍倒，木板与树叶掉在树旁；树桩会在 3 分钟后再生。'};
 }
 function explore(w,p){
  const t=shore(w,p.x,p.y);if(p.motion!=='ISLAND_GROUNDED'||t.r>1)return {ok:false,msg:'先游近沙滩自动登陆，再探索岛屿。'};
  if(w.worldClock-(p.lastForage??-100)<25)return {ok:false,msg:'这片灌丛需要休息，25 秒后可再次采集。'};
  p.lastForage=w.worldClock;p.inventory.potato=(p.inventory.potato||0)+1;
  return {ok:true,msg:`在${t.island.name}找到土豆 ×1；树木需手持斧头砍伐。`};
 }
 return {ensure,tick,terrain,shore,selectTree,chop,explore,presets,TREE_REGROW_SECONDS,speciesNames,treeNames};
});
