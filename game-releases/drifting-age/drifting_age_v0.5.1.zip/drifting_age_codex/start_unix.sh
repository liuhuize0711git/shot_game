#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
node --version >/dev/null 2>&1 || { echo "Please install Node.js 18 or newer."; exit 1; }
npm start
