/* Shared, authoritative construction transactions. Map coordinates are 30 units/metre. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./items'),require('./targeting'),require('./movement'));else root.OceanBuilding=factory(root.OceanItems,root.OceanTargeting,root.OceanMovement);})(globalThis,function(I,T,M){
 'use strict';
 const modes=['place','build','armor','repair','demolish'],reach=4.5;
 const costs={build:{plank:4,plastic:2},armor:{scrap:4,plank:2},repair:{plank:2}};
 const id=prefix=>prefix+'_'+(typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+'_'+Math.random().toString(36).slice(2));
 const center=(gx,gy)=>({x:500+gx*48,y:350+gy*48});
 const tileAt=(w,gx,gy)=>(w.raft||[]).find(t=>t.gx===gx&&t.gy===gy);
 const supported=(w,s)=>!!tileAt(w,s.gx,s.gy);
 function recount(w){w.stations=Object.fromEntries(I.stations.map(k=>[k,(w.structures||[]).filter(s=>s.type===k).length]));}
 function ensure(w){
  if(!Array.isArray(w.raft))w.raft=[];
  for(const t of w.raft)if(!t.id)t.id=id('tile');
  if(!Array.isArray(w.structures)){
   w.structures=[];
   const cells=w.raft.slice().sort((a,b)=>a.gy-b.gy||a.gx-b.gx);
   let cursor=0;
   for(const type of I.stations){
    const quantity=Math.max(0,Math.floor(Number(w.stations?.[type])||0));
    for(let i=0;i<quantity;i++){
     const cell=cells[cursor++];
     if(cell)w.structures.push({id:id('station'),type,gx:cell.gx,gy:cell.gy,...center(cell.gx,cell.gy),rotation:0});
     else {const cell0=cells[0],q=cell0?center(cell0.gx,cell0.gy):{x:500,y:350};I.spawnDrop(w,type,1,q.x,q.y,cell0?.8:.44,{tool:true,source:'migration'});}
    }
   }
  }
  for(const s of w.structures){if(!s.id)s.id=id('station');Object.assign(s,center(s.gx,s.gy));s.rotation=((Math.round(Number.isFinite(s.rotation)?s.rotation:0)%4)+4)%4;}
  recount(w);return w;
 }
 function removeUnsupported(w){
  ensure(w);const gone=[];
  w.structures=w.structures.filter(s=>{if(supported(w,s))return true;gone.push(s);I.spawnDrop(w,s.type,1,s.x,s.y,.44,{tool:true,source:'support'});return false;});
  // A drop remains at its horizontal location when its supporting deck disappears.
  for(const r of w.resources||[])if((r.persistent||r.dropTool||r.dropItem)&&r.altitude>.52&&r.altitude<1&&!M.overRaft(w,r)){
   const shore=M.shore(w,r.x,r.y);if(shore.r>1)r.altitude=.44;
  }
  recount(w);return gone;
 }
 function aim(w,p,view){
  if(!p||!view)return null;
  const c=T.camera(w,p,view),dy=c.forward[1];
  if(dy>=-.015)return null;
  const distance=(.52-c.eye[1])/dy;if(distance<=0||distance>45)return null;
  const x=(c.eye[0]+c.forward[0]*distance)*30+500,y=(c.eye[2]+c.forward[2]*distance)*30+350;
  if(!Number.isFinite(x)||!Number.isFinite(y))return null;
  const gx=Math.round((x-500)/48),gy=Math.round((y-350)/48),q=center(gx,gy);
  return {gx,gy,...q,hitX:x,hitY:y};
 }
 function preview(w,p,view,mode='place',rotation=0){
  ensure(w);
  const aimed=aim(w,p,view),base={ok:false,msg:'向下瞄准附近木筏，出现预览后按左键。',mode};
  if(!aimed)return base;
  const result={...base,...aimed,rotation:((Math.round(Number.isFinite(rotation)?rotation:0)%4)+4)%4};
  const fail=msg=>Object.assign(result,{ok:false,msg});
  if(!modes.includes(mode))return fail('请选择放置、扩建、强化、修理或拆除。');
  if(!p||p.down||p.boarding||!M.onRaft(w,p))return fail('请先站稳在木筏上。');
  if(Math.hypot(p.x-aimed.x,p.y-aimed.y)>reach*30)return fail('目标太远，请靠近后操作。');
  const tile=tileAt(w,aimed.gx,aimed.gy),structure=w.structures.find(s=>s.gx===aimed.gx&&s.gy===aimed.gy);
  Object.assign(result,{kind:'tile',targetId:tile?.id||null,type:null});
  if(mode==='build'){
   if(tile)return fail('这个位置已有地板。');
   const neighbors=w.raft.filter(t=>Math.abs(t.gx-aimed.gx)+Math.abs(t.gy-aimed.gy)===1);
   if(!neighbors.length)return fail('新地板必须与现有木筏边缘相连。');
   result.targetId='edge:'+neighbors.map(t=>t.id).sort().join(',');
  }else if(!tile)return fail('准星所指位置没有木筏地板。');
  if(mode==='place'){
   const type=I.held(p);result.type=type;result.kind='structure';
   if(!I.stations.includes(type)||I.count(p,type)<1)return fail('先制作并手持要放置的设施。');
   if(structure)return fail('这块地板已有设施，请选择空位。');
  }
  if(mode==='armor'&&tile.armored)return fail('这块地板已经强化。');
  if(mode==='repair'&&tile.hp>=(tile.armored?180:100))return fail('这块地板无需修理。');
  if(mode==='demolish'&&structure)Object.assign(result,{kind:'structure',type:structure.type,targetId:structure.id});
  if(costs[mode]&&Object.entries(costs[mode]).some(([key,n])=>(p.inventory?.[key]||0)<n))return fail('材料不足：'+Object.entries(costs[mode]).map(([key,n])=>({plank:'木板',plastic:'塑料',scrap:'废料'}[key]+' ×'+n)).join('、'));
  result.ok=true;result.msg={place:'左键放置 · R 旋转',build:'左键扩建这一格',armor:'左键强化这一块地板',repair:'左键修理这一块地板',demolish:structure?'左键拆除设施，变为原地掉落物':'左键拆除地板，回收一半建造材料'}[mode];
  return result;
 }
 function perform(w,p,mode,data={}){
  if(!data.view||!Number.isInteger(data.gx)||!Number.isInteger(data.gy)||typeof data.targetId!=='string')return {ok:false,msg:'请瞄准明确的建造目标后操作。'};
  const choice=preview(w,p,data.view,mode,data.rotation);
  if(!choice.ok)return choice;
  if(choice.gx!==data.gx||choice.gy!==data.gy||choice.targetId!==data.targetId)return {ok:false,msg:'目标已改变，请重新瞄准。'};
  const tile=tileAt(w,choice.gx,choice.gy);
  if(costs[mode])for(const [key,n]of Object.entries(costs[mode]))p.inventory[key]-=n;
  if(mode==='place'){
   p.tools[choice.type]--;
   w.structures.push({id:id('station'),type:choice.type,gx:choice.gx,gy:choice.gy,x:choice.x,y:choice.y,rotation:choice.rotation});
  }else if(mode==='build')w.raft.push({id:id('tile'),gx:choice.gx,gy:choice.gy,hp:100,armored:false});
  else if(mode==='armor'){tile.armored=true;tile.hp=180;}
  else if(mode==='repair')tile.hp=tile.armored?180:100;
  else if(mode==='demolish'){
   if(choice.kind==='structure'){
    const s=w.structures.find(s=>s.id===choice.targetId);w.structures=w.structures.filter(q=>q!==s);
    I.spawnDrop(w,s.type,1,s.x,s.y,.8,{tool:true,source:'demolition'});
   }else {
    w.raft=w.raft.filter(t=>t!==tile);
    I.spawnDrop(w,'plank',2,choice.x-7,choice.y,.44,{source:'demolition'});
    I.spawnDrop(w,'plastic',1,choice.x+7,choice.y,.44,{source:'demolition'});
    if(tile.armored)I.spawnDrop(w,'scrap',2,choice.x,choice.y+9,.44,{source:'demolition'});
    removeUnsupported(w);
   }
  }
  recount(w);
  return {ok:true,msg:{place:'设施已放置在选定位置。',build:'已扩建选定地板。',armor:'选定地板已强化。',repair:'选定地板已修好。',demolish:'已拆除，掉落物留在原地，可瞄准拾取。'}[mode],choice};
 }
 return {modes,costs,reach,center,ensure,removeUnsupported,aim,preview,perform};
});
