/* A passing current for ocean debris; player-created drops never enter it. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.OceanDrift=factory();})(globalThis,function(){
 'use strict';
 const permanent=r=>!!(r.stationary||r.dropTool||r.dropItem||r.source==='demolition'||r.source==='tree');
 function seed(w){
  // Reachable with empty hands from the initial 3x3 raft. Later waves pass both sides.
  w.resources=[['plank',440,267],['plastic',480,267],['leaf',525,267],['scrap',565,267],['barrel',590,325],['stone',410,325]].map(([type,x,y],i)=>({id:'current_start_'+i,type,x,y,phase:i,amount:1}));
  w.nextResource=0;w.driftSerial=0;
 }
 function tick(w,dt){
  w.nextResource=(w.nextResource||0)+dt;
  for(const r of w.resources||[]){
   if(permanent(r))continue;
   r.x+=3*dt;r.y+=18*dt;
   // Installed collection nets intercept actual debris, leaving a fixed pickup on deck.
   const net=(w.structures||[]).find(s=>s.type==='net'&&Math.hypot(s.x-r.x,s.y-r.y)<30);
   if(net){r.x=net.x;r.y=net.y;r.altitude=.8;r.stationary=true;r.source='net';if(r.type!=='barrel'){r.dropItem=true;r.amount=['plank','leaf'].includes(r.type)?2:1;}}
  }
  // Preserve player drops even beyond the current's visible lane or when nobody is nearby.
  w.resources=(w.resources||[]).filter(r=>permanent(r)||(r.x>-1000&&r.x<2400&&r.y<1050));
  if(w.nextResource>=2.5){
   w.nextResource%=2.5;
   if(w.resources.filter(r=>!permanent(r)).length<60){
    const types=['plank','plastic','leaf','plank','scrap','barrel','stone'];
    const n=w.driftSerial=(w.driftSerial||0)+1;
    w.resources.push({id:'current_'+Date.now().toString(36)+'_'+n,type:types[n%types.length],x:350+(n*73%280),y:110,amount:1,phase:n});
   }
  }
 }
 return {seed,tick,permanent};
});
