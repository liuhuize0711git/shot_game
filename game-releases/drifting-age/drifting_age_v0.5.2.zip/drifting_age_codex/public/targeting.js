/* Camera-space preselection shared with the authoritative pickup validation. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./movement'));else root.OceanTargeting=factory(root.OceanMovement);})(globalThis,function(M){
 'use strict';
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),sub=(a,b)=>a.map((v,i)=>v-b[i]);
 const norm=a=>{const l=Math.hypot(...a)||1;return a.map(v=>v/l);};
 const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
 const seabed=(x,z)=>Math.sin(x*.13)*.38+Math.cos(z*.16)*.32+Math.sin((x+z)*.21)*.17+Math.cos((x-z)*.09)*.11;
 function camera(w,p,v={}){
  const yaw=Number.isFinite(v.yaw)?v.yaw:0,pitch0=clamp(Number.isFinite(v.pitch)?v.pitch:.42,-1.05,1.2),dist=clamp(Number.isFinite(v.dist)?v.dist:9.2,5.8,15);
  const under=M.diving(w,p),swim=['SURFACE_SWIM','UNDERWATER'].includes(p.motion)&&!under,base=p.altitude??.52;
  const pitch=under?(v.upward?-.72:clamp(pitch0,-.82,.18)):pitch0,d=dist*(under?.70:swim?.82:1),horizontal=d*Math.cos(pitch),vertical=d*Math.sin(pitch);
  const x=(p.x-500)/30,z=(p.y-350)/30;
  const target=[x,base+(under?.24:swim?.78:1.05),z],eye=[x+Math.sin(yaw)*horizontal,under?clamp(base+vertical,-8.2,-.28):base+vertical,z+Math.cos(yaw)*horizontal];
  const forward=norm(sub(target,eye)),right=norm(cross(forward,[0,1,0])),up=cross(right,forward);
  // Shoulder offset keeps the avatar out of the central pickup circle.
  for(let i=0;i<3;i++){eye[i]+=right[i]*.85;target[i]+=right[i]*.85;}
  return {eye,target,forward,right,up,aspect:clamp(Number.isFinite(v.aspect)?v.aspect:1.5,.3,4)};
 }
 function point(r,underwater=false){const x=(r.x-500)/30,z=(r.y-350)/30;return [x,underwater?-8.08+seabed(x,z)+.4:(r.altitude??.44),z];}
 function project(c,q){const d=sub(q,c.eye),depth=dot(d,c.forward);if(depth<=.1)return null;const scale=Math.tan(Math.PI/6)*depth;return {x:dot(d,c.right)/(scale*c.aspect),y:dot(d,c.up)/scale,depth};}
 function occluded(w,eye,q){
  const length=Math.hypot(...sub(q,eye)),steps=Math.ceil(length/.06);
  for(let i=1;i<steps-2;i++){
   const t=i/steps,x=eye[0]+(q[0]-eye[0])*t,y=eye[1]+(q[1]-eye[1])*t,z=eye[2]+(q[2]-eye[2])*t;
   const p={x:x*30+500,y:z*30+350};
   if(y>.12&&y<.52&&M.overRaft(w,p))return true;
   const shore=M.shore(w,p.x,p.y);if(shore.r<=1&&y<shore.height)return true;
  }
  return false;
 }
 function select(w,p,view){
  if(!p||p.down||p.boarding)return null;
  const c=camera(w,p,view),under=M.diving(w,p);let best=null;
  const candidates=[...(w.resources||[]).filter(r=>under?(r.altitude??.44)<-.5:(r.altitude??.44)>=-.5).map(r=>({resource:r,underwater:false})),...(under?w.underwaterResources||[]:[]).map(r=>({resource:r,underwater:true}))];
  for(const candidate of candidates){
   const r=candidate.resource,q=point(r,candidate.underwater);
   const reach=Math.hypot((p.x-r.x)/30,(p.y-r.y)/30,(p.altitude+(under?.3:1))-q[1]);
   if(reach>2.8)continue;
   const screen=project(c,q);if(!screen)continue;
   const offset=Math.hypot(screen.x*c.aspect,screen.y);
   if(offset>.14||occluded(w,c.eye,q))continue;
   if(!best||offset<best.offset-.001||(Math.abs(offset-best.offset)<.001&&screen.depth<best.depth))best={...candidate,offset,depth:screen.depth,screen,point:q};
  }
  return best;
 }
 function validate(w,p,data){
  if(!data||typeof data.targetId!=='string'||!data.view)return null;
  const selected=select(w,p,data.view);return selected&&selected.resource.id===data.targetId?selected:null;
 }
 return {camera,point,project,select,validate,occluded};
});
