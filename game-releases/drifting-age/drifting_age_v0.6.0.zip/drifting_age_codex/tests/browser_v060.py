"""v0.6.0 integration on real WebGL Chromium (no rendering mock).

Run from project root: python3 tests/browser_v060.py.
Solo fixtures are injected into the test response only. Online checks use the
normal server and WebSocket protocol, with no server state injection.
"""
from pathlib import Path
import atexit
import json
import os
import socket
import subprocess
import time
from urllib.request import urlopen
from playwright.sync_api import sync_playwright

BASE = os.environ.get('TEST_BASE')
if not BASE:
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        port = probe.getsockname()[1]
    server = subprocess.Popen(['node', 'server.js'], env={**os.environ, 'PORT': str(port)}, stdout=subprocess.DEVNULL)
    def cleanup():
        if server.poll() is None:
            server.terminate()
            server.wait(timeout=5)
    atexit.register(cleanup)
    BASE = f'http://127.0.0.1:{port}'
    for _ in range(100):
        try:
            with urlopen(BASE) as response:
                assert response.status == 200
            break
        except OSError:
            time.sleep(.05)
    else:
        raise RuntimeError('Isolated test server failed to start')

ART = Path('docs/artifacts')
ART.mkdir(parents=True, exist_ok=True)
RESULT = Path('docs/browser-results-v0.6.0.json')
RESULT.unlink(missing_ok=True)
SOURCE = Path('public/index.html').read_text()
HOOK = r'''let qaPaused=false,qaRenderPaused=false;window.qa={
 renderPause(){qaRenderPaused=true;},run(code){return eval(code);},
 get(){return {me:me&&JSON.parse(JSON.stringify(me)),state:state&&JSON.parse(JSON.stringify(state)),selected:preselected?.resource.id,view:currentView(),webgl:!!gl&&!!program,glError:gl&&gl.getError(),renderError,camYaw,bindings:{...bindings},audioState:audioCtx?.state,musicVolume};},
 fresh(){qaPaused=true;mode='solo';gameStarted=true;state=freshState();OceanWorld.ensure(state);OceanBuilding.ensure(state);me=freshPlayer();me.x=500;state.players=[me];OceanMovement.normalize(state,me);OceanItems.slots(me);input={};camYaw=0;camPitch=.42;camDist=9.2;buildMode=null;buildRotation=0;syncHUD();},
 set(p){Object.assign(me,p);delete me.motion;delete me.boarding;OceanMovement.normalize(state,me);syncHUD();},
 full(){me.inventory={plank:20,plastic:20,leaf:20,scrap:20,stone:1,food:1,water:1};me.tools={hook:1,spear:1,axe:1,rod:1};me.hotbar=[...OceanItems.defaults];me.selectedSlot=4;syncHUD();},
 resources(r){state.resources=r;},
 tick(keys,seconds){input={...keys};for(let t=0;t<seconds-1e-8;t+=1/60)updateLocal(Math.min(1/60,seconds-t));input={};syncHUD();return JSON.parse(JSON.stringify(me));},
 keys(k){input={...k};sendInputs();},view(yaw,pitch=.42,dist=9.2){camYaw=yaw;camPitch=pitch;camDist=dist;},
 act(a,d){return localAction(a,d||{});},send(a,d){sendAction(a,d||{});},save(){saveSolo();},
 aim(id){for(let yaw=-Math.PI;yaw<Math.PI;yaw+=.09)for(let pitch=-1;pitch<1.2;pitch+=.055){const v={yaw,pitch,dist:camDist,aspect:canvas.clientWidth/canvas.clientHeight,upward:false};const t=OceanTargeting.select(state,me,v);if(t&&(!id||t.resource.id===id)){camYaw=yaw;camPitch=pitch;updatePreselection();return t.resource.id;}}return null;},
 aimBuild(mode,gx,gy,rotation=0){for(let yaw=-Math.PI;yaw<Math.PI;yaw+=.07)for(let pitch=.20;pitch<1.2;pitch+=.035){const v={yaw,pitch,dist:camDist,aspect:canvas.clientWidth/canvas.clientHeight,upward:false};const t=OceanBuilding.preview(state,me,v,mode,rotation);if(t&&t.gx===gx&&t.gy===gy&&t.ok){camYaw=yaw;camPitch=pitch;return {...t,view:v,rotation};}}return null;},
 aimTree(id){for(let yaw=-Math.PI;yaw<Math.PI;yaw+=.09)for(let pitch=-.4;pitch<1.2;pitch+=.055){const v={yaw,pitch,dist:camDist,aspect:canvas.clientWidth/canvas.clientHeight,upward:false};const t=OceanWorld.selectTree(state,me,v,OceanTargeting);if(t&&(!id||t.tree.id===id)){camYaw=yaw;camPitch=pitch;return {targetId:t.tree.id,view:v};}}return null;},
 request(){return pickupRequest();}
};'''
INSTRUMENTED = SOURCE.replace("if(mode==='solo')updateLocal(dt);", "if(mode==='solo'&&!qaPaused)updateLocal(dt);").replace(' if(!state||!me){', ' if(qaRenderPaused){requestAnimationFrame(render3D);return;}\n if(!state||!me){', 1).replace('})();\n</script>', HOOK + '})();\n</script>')
assert INSTRUMENTED != SOURCE and 'window.qa=' in INSTRUMENTED
results = {}

def empty_inventory(player):
    return all(n == 0 for n in player['inventory'].values()) and all(n == 0 for n in player['tools'].values())

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    context = browser.new_context(viewport={'width': 1200, 'height': 800}, permissions=['local-network-access'])
    context.route('**/index.html', lambda route: route.fulfill(body=INSTRUMENTED, content_type='text/html'))
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto(BASE + '/index.html')
    page.click('#startBtn')
    page.wait_for_function('qa.get().me!==null')
    initial = page.evaluate(r'qa.get()')
    assert initial['webgl'] and not initial['renderError'], initial
    assert empty_inventory(initial['me']), initial['me']
    assert initial['me']['hotbar'] == [None] * 10
    page.evaluate(r'qa.fresh();qa.view(0,.5,5.8);qa.set({yaw:Math.PI})')
    page.wait_for_timeout(200)
    page.screenshot(path=str(ART / 'v0.6.0-human-empty-start.png'))
    results['empty_start'] = 'PASS: actual first solo entry has no materials/tools, all ten hotbar slots empty; human avatar rendered in real WebGL'

    # Retain the full-bar and pointer-lock regression from v0.5.2.
    page.keyboard.press('Escape')
    page.evaluate(r'qa.full()')
    page.locator('#recipes button').filter(has_text='水瓶').click()
    page.wait_for_timeout(1200)
    player = page.evaluate(r'qa.get().me')
    assert player['hotbar'][player['selectedSlot']] == 'bottle' and player['tools']['bottle'] == 1
    drops = page.evaluate(r'qa.get().state.resources.filter(r=>r.dropItem)')
    assert len(drops) == 1 and drops[0]['amount'] == 20 and drops[0]['type'] == 'plank'
    page.mouse.click(600, 390)
    page.wait_for_function('document.pointerLockElement===document.querySelector("#gl")')
    assert page.evaluate(r'(id)=>qa.aim(id)', drops[0]['id']) == drops[0]['id']
    page.keyboard.press('e')
    assert page.evaluate(r'qa.get().me.inventory.plank') == 20
    results['full_bar_and_mouse'] = 'PASS: Escape/craft/canvas click restores view; new craft equipped; old held stack dropped and all 20 planks recovered by aimed E'

    # New players can immediately hand-pick debris into a usable hotbar slot.
    page.evaluate(r'qa.fresh();qa.resources([{id:"aimed",type:"plank",x:526,y:285,altitude:.8},{id:"closer",type:"plastic",x:460,y:340,altitude:.8}])')
    page.wait_for_function('qa.get().selected==="aimed"')
    page.keyboard.press('e')
    assert page.evaluate(r'qa.get().me.inventory.plank') == 2
    assert 'plank' in page.evaluate(r'qa.get().me.hotbar')
    assert page.evaluate(r'qa.get().state.resources.map(r=>r.id)') == ['closer']
    results['empty_start_pickup'] = 'PASS: bare-handed targeted pickup fills empty hotbar; nearer off-axis debris is not collected'

    # Place real crafted/held objects on chosen cells using normal left-click routing.
    page.evaluate(r'qa.fresh();qa.run("me.inventory={plank:60,plastic:30,scrap:30};me.tools={purifier:2};me.hotbar=[\"purifier\",null,null,null,null,null,null,null,null,null];me.selectedSlot=0;syncHUD();")')
    first = page.evaluate(r'qa.aimBuild("place",1,0,1)')
    assert first, 'Cannot aim at selected placement cell'
    page.evaluate(r'qa.run("buildRotation=1")')
    page.wait_for_timeout(200)
    page.screenshot(path=str(ART / 'v0.6.0-placement-preview.png'))
    page.mouse.click(600, 390)
    placed = page.evaluate(r'qa.get().state.structures')
    assert len(placed) == 1 and (placed[0]['gx'], placed[0]['gy'], placed[0]['rotation']) == (1, 0, 1), placed
    second = page.evaluate(r'qa.aimBuild("place",-1,0,0)')
    assert second
    page.evaluate(r'qa.run("buildRotation=0")')
    page.mouse.click(600, 390)
    assert sorted((s['gx'], s['gy']) for s in page.evaluate(r'qa.get().state.structures')) == [(-1, 0), (1, 0)]
    # Upgrade exactly the aimed tile and reject a stale target without consumption.
    request = page.evaluate(r'qa.aimBuild("armor",1,0)')
    assert request
    assert page.evaluate(r'(data)=>qa.act("armor",data)', request)['ok']
    assert page.evaluate(r'qa.get().state.raft.filter(t=>t.armored).map(t=>[t.gx,t.gy])') == [[1, 0]]
    before = page.evaluate(r'qa.get().me.inventory')
    assert not page.evaluate(r'(data)=>qa.act("armor",data)', request)['ok']
    assert page.evaluate(r'qa.get().me.inventory') == before
    # Expansion uses a specified empty edge cell; structures demolish to a recoverable object.
    request = page.evaluate(r'qa.aimBuild("build",0,2)')
    assert request
    assert page.evaluate(r'(data)=>qa.act("build",data)', request)['ok']
    assert page.evaluate(r'qa.get().state.raft.some(t=>t.gx===0&&t.gy===2)')
    request = page.evaluate(r'qa.aimBuild("demolish",1,0)')
    assert request
    assert page.evaluate(r'(data)=>qa.act("demolish",data)', request)['ok']
    assert page.evaluate(r'qa.get().state.structures.length') == 1
    salvage = page.evaluate(r'qa.get().state.resources.filter(r=>r.source==="demolition")')
    assert len(salvage) == 1 and salvage[0]['type'] == 'purifier' and salvage[0]['amount'] == 1
    assert page.evaluate(r'(id)=>qa.aim(id)', salvage[0]['id']) == salvage[0]['id']
    page.keyboard.press('e')
    assert page.evaluate(r'qa.get().me.tools.purifier') == 1
    page.wait_for_timeout(100)
    page.screenshot(path=str(ART / 'v0.6.0-custom-raft.png'))
    results['targeted_building'] = 'PASS: left-click places two held facilities at two chosen cells, rotation retained; exact tile upgrade and edge expansion; repeated upgrade costs nothing; aimed demolition creates original facility drop and E retrieves it'

    # Ambient current carries debris past the player; discarded objects survive outside its lane.
    page.evaluate(r'qa.fresh();qa.run("me.inventory={plank:2};me.hotbar=[\"plank\",null,null,null,null,null,null,null,null,null];state.resources=[{id:\"passing\",type:\"plastic\",x:500,y:1040,phase:0}];")')
    assert page.evaluate(r'qa.act("drop")')['ok']
    dropped = page.evaluate(r'qa.get().state.resources.find(r=>r.dropItem)')
    page.evaluate(r'qa.run("OceanDrift.tick(state,2)")')
    after = page.evaluate(r'(id)=>qa.get().state.resources.find(r=>r.id===id)', dropped['id'])
    assert all(after[k] == dropped[k] for k in ('x', 'y', 'altitude', 'amount'))
    assert not page.evaluate(r'qa.get().state.resources.some(r=>r.id==="passing")')
    page.evaluate(r'qa.run("state.resources.find(r=>r.dropItem).x=2200;state.resources.find(r=>r.dropItem).y=1800;OceanDrift.tick(state,200);saveSolo();")')
    saved = page.evaluate(r'JSON.parse(localStorage.getItem("driftingAge3dSave"))')
    assert any(r['id'] == dropped['id'] and r['x'] == 2200 and r['y'] == 1800 for r in saved['resources'])
    results['debris_persistence'] = 'PASS: uncollected current debris leaves scene; discarded stack retains exact position/amount and remains in save even outside current lane after 200 simulated seconds'

    # Each modeled island is reachable through continuous surface swimming and boarding.
    page.evaluate(r'qa.fresh()')
    islands = page.evaluate(r'qa.get().state.islands')
    assert len(islands) == 3 and len({island['biome'] for island in islands}) == 3
    for island in islands:
        page.evaluate(r'(i)=>{qa.view(0);qa.set({x:i.x+i.rx*1.02,y:i.y,altitude:-.34});}', island)
        player = page.evaluate(r'qa.tick({left:true,upward:true},1.4)')
        assert player['motion'] == 'ISLAND_GROUNDED', (island['id'], player)
        player = page.evaluate(r'qa.tick({left:true},.5)')
        height = page.evaluate(r'qa.run("OceanWorld.shore(state,me.x,me.y).height")')
        assert abs(player['altitude'] - height) < 1e-7
    assert set(page.evaluate(r'qa.get().state.animals.map(a=>a.species)')) >= {'goat', 'horse', 'boar', 'gull', 'parrot'}
    page.evaluate(r'qa.run("const i=state.islands[1];me.x=i.x+40;me.y=i.y+85;me.altitude=OceanWorld.shore(state,me.x,me.y).height;me.motion=\"ISLAND_GROUNDED\";me.yaw=0;OceanWorld.tick(state,1,[]);syncHUD();");qa.view(.4,.55,11)')
    page.wait_for_timeout(300)
    page.screenshot(path=str(ART / 'v0.6.0-meadow-animals.png'))
    results['island_landing'] = 'PASS: actual movement simulation swims/automatically boards all 3 different islands; walking matches terrain height; world has goats, horses, boars, gulls and parrots; actual meadow WebGL screenshot'

    # Axe is required and targeted; felling leaves fixed resources and a renewable stump.
    page.evaluate(r'qa.run("const t=state.trees[0];me.x=t.x;me.y=t.y+50;me.altitude=OceanWorld.shore(state,me.x,me.y).height;me.motion=\"ISLAND_GROUNDED\";me.tools={axe:1};me.hotbar=[\"axe\",null,null,null,null,null,null,null,null,null];me.selectedSlot=0;buildMode=null;syncHUD();");qa.view(0,.42,5.8)')
    tree = page.evaluate(r'qa.get().state.trees[0]')
    request = page.evaluate(r'(id)=>qa.aimTree(id)', tree['id'])
    assert request, 'Cannot aim at harvestable tree'
    page.wait_for_timeout(100)
    page.screenshot(path=str(ART / 'v0.6.0-tree-target.png'))
    for hit in range(3):
        assert page.evaluate(r'(data)=>qa.act("chop",data)', request)['ok']
        if hit < 2:
            page.evaluate(r'qa.run("OceanWorld.tick(state,.5,[])")')
    assert page.evaluate(r'qa.get().state.trees[0].hp') == 0
    wood = page.evaluate(r'(id)=>qa.get().state.resources.filter(r=>r.id.startsWith(id))', tree['id'])
    assert sorted((r['type'], r['amount']) for r in wood) == [('leaf', 2), ('plank', 4)]
    assert all(r['dropItem'] for r in wood)
    page.wait_for_timeout(100)
    page.screenshot(path=str(ART / 'v0.6.0-tree-salvage.png'))
    page.evaluate(r'qa.run("OceanWorld.tick(state,179.9,[])")')
    assert page.evaluate(r'qa.get().state.trees[0].hp') == 0
    page.evaluate(r'qa.run("OceanWorld.tick(state,.2,[])")')
    assert page.evaluate(r'qa.get().state.trees[0].hp') == 3
    assert page.evaluate(r'(id)=>qa.get().state.resources.filter(r=>r.id.startsWith(id))', tree['id']) == wood
    results['renewable_trees'] = 'PASS: aimed axe needs 3 swings; 4 planks and 2 leaves fall at tree; stump remains until 180 seconds and regrows; old drops remain unchanged'

    # Real audio synthesis: three distinct musical scores render non-silent, nonconstant samples.
    audio = page.evaluate(r'''async () => {
      const stats=[];
      for(let i=0;i<OceanMusic.tracks.length;i++){
        const ctx=new OfflineAudioContext(1,22050*4,22050);
        OceanMusic.renderTrack(ctx,i,{seconds:4});
        const buffer=await ctx.startRendering(),samples=buffer.getChannelData(0);
        let sum=0,peak=0,delta=0;
        for(let n=1;n<samples.length;n++){sum+=samples[n]*samples[n];peak=Math.max(peak,Math.abs(samples[n]));delta+=Math.abs(samples[n]-samples[n-1]);}
        stats.push({title:OceanMusic.tracks[i].title,rms:Math.sqrt(sum/samples.length),peak,delta});
      }return stats;
    }''')
    assert len(audio) >= 3 and len({track['title'] for track in audio}) >= 3
    assert all(track['rms'] > .00001 and track['delta'] > 1 for track in audio), audio
    assert len({round(track['rms'], 7) for track in audio}) == len(audio)
    indices = page.evaluate(r'qa.run("const ids=[];for(let i=0;i<4;i++){ids.push(musicPlayer.index);musicPlayer.next();}ids;")')
    assert indices[0] == indices[3] and len(set(indices[:3])) == 3, indices
    page.keyboard.press('Escape')
    page.click('#settingsBtn')
    page.locator('#musicVolume').fill('0')
    page.locator('#musicVolume').dispatch_event('input')
    assert page.evaluate(r'qa.get().musicVolume') == 0
    assert page.evaluate(r'JSON.parse(localStorage.getItem("driftingAgeAudio")).music') == 0
    assert page.evaluate(r'qa.run("musicGain.gain.value")') == 0
    page.click('#settingsDone')
    results['music'] = {'result': 'PASS: 3 distinct tracks synthesize actual nonconstant audio; player cycles all three; zero music volume mutes output and persists; no human listening claim', 'rendered_tracks': audio}
    assert page.evaluate(r'qa.get().glError') == 0
    assert not errors, errors
    context.close()

    online = browser.new_context(viewport={'width': 800, 'height': 600}, permissions=['local-network-access'])
    online.route('**/index.html', lambda route: route.fulfill(body=INSTRUMENTED, content_type='text/html'))
    clients = []
    for index in range(2):
        client = online.new_page()
        clients.append(client)
        client.on('pageerror', lambda error: errors.append(str(error)))
        client.goto(BASE + '/index.html')
        client.locator('[data-mode="coop"]').click()
        client.click('#startBtn')
        client.wait_for_function('qa.get().me!==null', polling=100)
        client.evaluate('qa.renderPause()')
    a, b = clients
    a.wait_for_function('qa.get().state.players.length===2', polling=100)
    for client in clients:
        assert empty_inventory(client.evaluate('qa.get().me'))
        assert client.evaluate('qa.get().me.hotbar') == [None] * 10
    assert a.evaluate('qa.get().state.islands.map(i=>i.id)') == b.evaluate('qa.get().state.islands.map(i=>i.id)')
    demolition = a.evaluate('qa.aimBuild("demolish",0,1)')
    assert demolition
    a.evaluate('(d)=>qa.send("demolish",d)',demolition)
    b.wait_for_function('qa.get().state.raft.length===8',polling=100)
    a.wait_for_function('qa.get().state.resources.filter(r=>r.source==="demolition").length===2',polling=100)
    a.evaluate('(d)=>qa.send("demolish",d)',demolition)
    a.wait_for_timeout(200)
    assert a.evaluate('qa.get().state.resources.filter(r=>r.source==="demolition").length')==2
    dropid=a.evaluate('qa.get().state.resources.find(r=>r.source==="demolition"&&r.type==="plank").id')
    assert a.evaluate('(id)=>qa.aim(id)',dropid)==dropid
    a.evaluate('qa.send("pickup",qa.request())')
    a.wait_for_function('qa.get().me.inventory.plank===2',polling=100)
    b.wait_for_function('(id)=>!qa.get().state.resources.some(r=>r.id===id)',arg=dropid,polling=100)
    results['multiplayer_transactions']='PASS: normal server validates aimed demolition, both clients see exact tile removed and two stationary salvage drops; replay does not duplicate drops; targeted salvage pickup synchronizes to observer.'
    before = a.evaluate('qa.get().me.inventory')
    a.evaluate('qa.send("pickup",{targetId:"fabricated",view:qa.get().view})')
    a.wait_for_timeout(200)
    assert a.evaluate('qa.get().me.inventory') == before
    full = a.evaluate('''() => new Promise(resolve=>{const socket=new WebSocket(`ws://${location.host}/?name=third`);socket.onmessage=e=>{const msg=JSON.parse(e.data);if(msg.type==='full')resolve(msg.type);};setTimeout(()=>resolve('timeout'),3000);})''')
    assert full == 'full'
    b.close()
    a.wait_for_function('qa.get().state.players.length===1', polling=100)
    results['multiplayer'] = 'PASS: two actual browser/WebSocket clients start empty, share island IDs, reject forged pickup; third-player refusal and disconnect cleanup. Extra rendering paused after WebGL initialization in protocol phase.'
    assert not errors, errors
    results['webgl'] = 'PASS: real Chromium WebGL/ANGLE/SwiftShader, GL_NO_ERROR and no JavaScript page exceptions; screenshots from actual rendering'
    browser.close()

RESULT.write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(results, ensure_ascii=False, indent=2))
