'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const M=require('../public/movement');
function world(){const raft=[];for(let gx=-1;gx<=1;gx++)for(let gy=-1;gy<=1;gy++)raft.push({gx,gy,hp:100,armored:false});return {raft,island:{x:740,y:290,radius:120}};}
function player(extra={}){return {x:500,y:350,altitude:.52,oxygen:100,hp:100,...extra};}
function run(w,p,keys,seconds,dt=1/60){for(let t=0;t<seconds-1e-8;t+=dt)M.step(w,p,keys,Math.min(dt,seconds-t));}
test('new world has 9 supported tiles, including expansions and no missing-tile support',()=>{
 const w=world();assert.equal(w.raft.length,9);
 for(const t of w.raft){const p=player({x:500+t.gx*48,y:350+t.gy*48});run(w,p,{},.1);assert.equal(p.motion,'RAFT_GROUNDED');}
 w.raft.push({gx:2,gy:0});let p=player({x:596});run(w,p,{},.1);assert(M.onRaft(w,p));
 w.raft=w.raft.filter(t=>t.gx!==0||t.gy!==0);p=player();run(w,p,{},1);assert(!M.onRaft(w,p));assert(p.altitude<.52);
});
test('walk off deck continuously, sink past old -1.05 dead zone, ascend to surface',()=>{
 const w=world(),p=player();let last=p.altitude;
 for(let i=0;i<180;i++){M.step(w,p,{right:true},1/60);assert(Math.abs(p.altitude-last)<.06);last=p.altitude;}
 assert(!M.onRaft(w,p));run(w,p,{},3);assert(p.altitude<-2);
 let rose=false;for(let i=0;i<600;i++){const prev=p.altitude;M.step(w,p,{upward:true},1/60);assert(Math.abs(p.altitude-prev)<.04);if(p.altitude>prev)rose=true;assert(p.altitude<=M.SURFACE+.0001);}
 assert(rose);assert.equal(p.motion,'SURFACE_SWIM');assert.equal(p.altitude,M.SURFACE);
 run(w,p,{},.6);assert.equal(p.altitude,M.SURFACE);run(w,p,{},1.5);assert(p.altitude<-.8);
});
test('underside is solid, horizontal escape and side boarding work without crossing deck',()=>{
 const w=world(),p=player({altitude:-2});run(w,p,{upward:true},3);assert.equal(p.altitude,M.UNDERSIDE);assert(!M.interact(w,p));
 run(w,p,{right:true,upward:true},1.5);assert(p.x>572);run(w,p,{upward:true},2);assert.equal(p.altitude,M.SURFACE);
 // Swim towards the side: horizontal collision stops penetration at surface.
 run(w,p,{left:true,upward:true},1);assert(p.x>=572);assert(!M.overRaft(w,p));
 assert.equal(p.motion,'BOARDING');let prev={...p};
 for(let i=0;i<75;i++){M.step(w,p,{},1/60);assert(Math.abs(p.altitude-prev.altitude)<.04);if(M.overRaft(w,p))assert(p.altitude>=.52);prev={...p};}
 assert(M.onRaft(w,p));const before=p.x;run(w,p,{left:true},.15);assert(p.x<before);assert(M.onRaft(w,p));
});
test('exposed edges on all sides, internal edges rejected, removed climb destination cancels',()=>{
 const w=world();for(const [x,y] of [[575,350],[425,350],[500,425],[500,275]]){const p=player({x,y,altitude:M.SURFACE});assert(M.interact(w,p));run(w,p,{},1.3);assert(M.onRaft(w,p));}
 assert(!M.interact(w,player({altitude:M.SURFACE})));
 const p=player({x:575,altitude:M.SURFACE});assert(M.interact(w,p));w.raft=w.raft.filter(t=>t.gx!==p.boarding.gx||t.gy!==p.boarding.gy);run(w,p,{},1.4);assert(!p.boarding);assert(!M.onRaft(w,p));
});
test('island side landing follows terrain, permits inland walking and swimming away',()=>{
 const w=world(),p=player({x:890,y:290,altitude:-2});run(w,p,{left:true},1);assert(M.shore(w,p.x,p.y).r>1);
 run(w,p,{upward:true},4);assert.equal(p.altitude,M.SURFACE);assert(M.interact(w,p));run(w,p,{},1.3);assert(M.onIsland(w,p));
 let last=p.altitude;for(let i=0;i<50;i++){M.step(w,p,{left:true},1/60);assert(Math.abs(p.altitude-last)<.12);last=p.altitude;}
 assert(M.onIsland(w,p));assert(p.altitude>.3);run(w,p,{right:true},3);assert(!M.onIsland(w,p));assert(p.altitude<0);
});
test('oxygen depletes underwater/under deck and recovers on surface/deck/island',()=>{
 const w=world(),p=player({x:590,altitude:-2});run(w,p,{},1);assert(p.oxygen<92);
 run(w,p,{upward:true},6);assert.equal(p.oxygen,100);
 for(const loc of [{x:500,y:350,altitude:.52},{x:740,y:290,altitude:.62}]){const q=player({...loc,oxygen:30});run(w,q,{},1);assert(q.oxygen>=45);}
 const q=player({altitude:-2});run(w,q,{upward:true},3);assert(q.oxygen<80);
});
test('30/60/120 Hz and server 10 Hz agree on water trajectory and camera-relative movement',()=>{
 const w=world(),results=[];for(const dt of [1/10,1/30,1/60,1/120]){const p=player({x:590,altitude:-2});run(w,p,{up:true,upward:true,yaw:Math.PI/2},1,dt);results.push(p);}
 for(const p of results){assert(Math.abs(p.x-results[0].x)<1e-7);assert(Math.abs(p.altitude-results[0].altitude)<1e-7);assert.equal(p.motion,results[0].motion);}
});
test('old saves migrate and mid-climb saves resume; respawn clears stale state',()=>{
 const w=world(),p=player({x:575,altitude:M.SURFACE});M.interact(w,p);run(w,p,{},.4);const saved=JSON.parse(JSON.stringify(p));run(w,saved,{},1);assert(M.onRaft(w,saved));
 M.reset(w,p);assert(!p.boarding);assert(M.onRaft(w,p));
});

test('automatic boarding requires surface, outside edge and movement towards it',()=>{
 const w=world();
 for(const [x,y,k] of [[575,350,{left:true}],[425,350,{right:true}],[500,425,{up:true}],[500,275,{down:true}]]){const p=player({x,y,altitude:M.SURFACE});run(w,p,{...k,upward:true},1.4);assert(M.onRaft(w,p));}
 const still=player({x:575,altitude:M.SURFACE});run(w,still,{upward:true},2);assert.equal(still.motion,'SURFACE_SWIM');
 const away=player({x:575,altitude:M.SURFACE});run(w,away,{right:true,upward:true},.2);assert(!M.onRaft(w,away));assert(!away.boarding);
 const deep=player({x:575,altitude:-2});run(w,deep,{left:true},.3);assert(!deep.boarding);assert(!M.onRaft(w,deep));
 // A central missing tile is not an exterior edge.
 w.raft=w.raft.filter(t=>t.gx!==0||t.gy!==0);const hole=player({x:521,altitude:M.SURFACE});run(w,hole,{right:true,upward:true},1.5);assert(!hole.boarding);assert(!M.onRaft(w,hole));
});

test('tile seams support standing and surface approaches at seams/corners can board',()=>{
 const w=world(),seam=player({x:524,y:350});run(w,seam,{},.2);assert(M.onRaft(w,seam));
 for(const [x,y,k] of [[575,374,{left:true}],[575,423,{left:true,up:true}]]){const p=player({x,y,altitude:M.SURFACE});run(w,p,{...k,upward:true},1.4);assert(M.onRaft(w,p));assert(p.altitude===.52);}
});
