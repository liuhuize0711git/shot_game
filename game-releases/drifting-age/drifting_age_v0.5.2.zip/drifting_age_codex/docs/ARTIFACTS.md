# 0.5.2 真实 WebGL 截图

Chromium 154 + ANGLE/SwiftShader，非 mock。当前版图片：

- `artifacts/v0.5.2-crafted-equipped.png`：制作后装备。
- `artifacts/v0.5.2-aim-highlight.png`：模型轮廓高亮与圆区名称。
- `artifacts/v0.5.2-underwater-target.png`：海底预选。
- `artifacts/v0.5.2-auto-board.png`：自动登筏完成。

对应结果：`browser-results-v0.5.2.json`。

---

# 截图说明

## 0.5.1 真实 WebGL 验收

以下截图由 `tests/browser_smoke.py` 在 Chromium 154 / SwiftShader 的真实 WebGL 上下文中捕获，未使用 WebGL mock：

- `artifacts/v0.5.1-scene.png`：初始 3×3 木筏、人物、海面与本地程序模型。
- `artifacts/v0.5.1-reboarded.png`：离开木筏、下潜、上浮并从外侧 E 键登筏后的甲板状态。
- `artifacts/v0.5.1-shore.png`：从海滩登陆并向岛内行走后的岛屿状态。

- `artifacts/v0.5.1-underwater.png`：真实海底、游泳人物与资源区域。

浏览器逐项结果保存在 `browser-results.json`。

## 历史资料

`v0.5-start-automated.png` 与 `v0.5-settings-automated.png` 来自此前交接包，仅供 UI 历史参考，不能作为 3D 渲染通过的证据。
