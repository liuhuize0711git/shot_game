# 漂流纪元 0.5.0 测试记录

测试日期：2026-10-23

## 已执行并通过

### 静态与启动
- `node --check server.js`：通过。
- 从 HTML 提取的客户端 JavaScript `node --check`：通过。
- `npm start` 后 HTTP 首页返回 `200`：通过。

### 浏览器逻辑/UI 自动化
当前执行环境的 Chromium 不提供真实 WebGL context，因此为了检查界面和游戏逻辑，测试 harness 使用 no-op WebGL mock；该 mock **不用于视觉渲染验收**。
- 单人模式启动、10 格快捷栏生成：通过。
- 数字键选择快捷栏、左右方向键循环切换：通过。
- 相机鼠标增量处理可更新视角角度：通过。
- 设置面板打开、10 项可重设键位显示、音量滑块更新：通过。
- 绑定冲突（例如将前进改为已用于交互的 E）会拒绝修改，原键位不变：通过。
- 丢弃 1 个木板会将数量从 8 降到 7；捡回该掉落物恢复为 8，不会多给资源：通过。
- 从水下深度逐步上浮，不会瞬间传送到甲板：通过。
- 在木筏正下方持续按空格上浮时，位置被限制在甲板下方约 -0.72，无法穿过木筏：通过。
- JavaScript 页面异常：未发现。

### WebSocket 集成
- 两名客户端同时连接后，状态显示 2 名玩家、9 块木筏地板、最大玩家数为 2：通过。
- 第三名客户端加入时被拒绝：通过。
- 联机丢弃物品会减少玩家背包数量，并将 `dropItem` 掉落物同步到共享世界：通过。

## 尚未能在当前环境验证

- 当前运行环境的 Chromium 在多种 SwiftShader/WebGL 配置下均返回 `canvas.getContext('webgl') === null`。因此本报告**不宣称 GPU/WebGL 画面渲染已经通过视觉验收**。游戏保留真实 WebGL 渲染器，不以伪 3D 作为回退；请在支持 WebGL 的桌面 Chrome/Edge 中检查实际人物、海面、甲板和水下画面。
- 尚未完成两台真实电脑远程联机的长时间网络抖动、断线重连、真实音频设备与高负载 GPU 性能测试。
- 人物是更圆润的程序化低多边形卡通模型与程序动画，尚未使用高精度外部角色模型或专业骨骼动画。

## Codex handoff note — latest player feedback supersedes partial water tests

The previous automated checks confirmed that the vertical position changed gradually and that the player could not pass through the raft underside. However, the player subsequently reported a gameplay-blocking issue: after entering the water they cannot return to the raft or land on an island. Therefore the water/boarding system is **NOT ACCEPTED** despite those narrower automated checks. The desired rule is: while submerged, Space held gradually ascends to the water surface; Space released gradually sinks. Codex must implement and verify reboarding and island landing end-to-end.

## Handoff package integrity checks

Performed while preparing the Codex handoff bundle:
- `node --check server.js`: passed.
- Extracted inline JavaScript from `public/index.html`, then `node --check`: passed.
- Started server on `PORT=3137`, requested `/`, and compared response bytes with `public/index.html`: passed (HTTP response matched source exactly).
- ZIP archive integrity (`unzip -t`): passed.
- Real WebGL/GPU visual rendering: not verified in this environment; see above limitation. The two included screenshots are automated UI artifacts, not proof of a correct 3D scene.
