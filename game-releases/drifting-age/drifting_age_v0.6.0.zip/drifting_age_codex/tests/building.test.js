const {test}=require('node:test');const assert=require('node:assert/strict');
const B=require('../public/building'),I=require('../public/items');
function world(){const raft=[];for(let gx=-1;gx<=1;gx++)for(let gy=-1;gy<=1;gy++)raft.push({gx,gy,hp:100,armored:false});return {raft,resources:[],stations:{},island:{x:1000,y:1000,radius:80}};}
function player(){return {x:500,y:350,altitude:.52,motion:'RAFT_GROUNDED',inventory:{plank:40,plastic:20,scrap:20},tools:{chest:2,purifier:1},selectedSlot:0,hotbar:['chest','purifier',null,null,null,null,null,null,null,null]};}
const v={yaw:0,pitch:.65,dist:9.2,aspect:1.5};
function payload(w,p,mode,view=v){return {...B.preview(w,p,view,mode),view};}
test('targeted placement, rotation, occupancy and dismantling preserve exact facilities',()=>{
 const w=world(),p=player();const data=payload(w,p,'place');data.rotation=3;
 assert.equal(data.gx,1);assert.equal(data.gy,-1);assert(B.perform(w,p,'place',data).ok);
 assert.equal(w.structures.length,1);assert.deepEqual([w.structures[0].gx,w.structures[0].gy,w.structures[0].rotation],[1,-1,3]);assert.equal(w.stations.chest,1);assert.equal(p.tools.chest,1);
 assert(!B.perform(w,p,'place',data).ok);assert.equal(p.tools.chest,1);
 const remove=payload(w,p,'demolish');assert(B.perform(w,p,'demolish',remove).ok);assert.equal(w.structures.length,0);assert.equal(w.raft.length,9);assert.equal(w.stations.chest,0);
 const drop=w.resources[0];assert.equal(drop.type,'chest');assert.equal(drop.amount,1);assert(drop.persistent&&drop.dropTool);assert.equal(drop.source,'demolition');assert.deepEqual([drop.x,drop.y],[548,302]);
 assert(!B.perform(w,p,'demolish',remove).ok);assert.equal(w.raft.length,9);assert(I.collect(w,p,drop));assert.equal(p.tools.chest,2);
});
test('chosen tile upgrades and repairs; stale, remote and unsupported actions have no cost',()=>{
 const w=world(),p=player();B.ensure(w);const tile=w.raft.find(t=>t.gx===1&&t.gy===-1);
 const before=p.inventory.scrap;assert(B.perform(w,p,'armor',payload(w,p,'armor')).ok);assert.equal(tile.armored,true);assert.equal(tile.hp,180);assert.equal(p.inventory.scrap,before-4);assert.equal(w.raft.filter(t=>t.armored).length,1);
 assert(!B.perform(w,p,'armor',payload(w,p,'armor')).ok);tile.hp=62;
 assert(B.perform(w,p,'repair',payload(w,p,'repair')).ok);assert.equal(tile.hp,180);
 const bad={...payload(w,p,'demolish'),gx:0};const serialized=JSON.stringify(w);assert(!B.perform(w,p,'demolish',bad).ok);assert.equal(JSON.stringify(w),serialized);
 const far={...p,x:5000};assert(!B.perform(w,far,'demolish',payload(w,p,'demolish')).ok);
 p.motion='UNDERWATER';p.altitude=-2;assert(!B.perform(w,p,'place',payload(w,p,'place')).ok);
});
test('expansion uses aimed adjacent empty cell; demolition returns materials once',()=>{
 const w=world(),p=player(),view={...v,pitch:.42},data=payload(w,p,'build',view);
 assert.deepEqual([data.gx,data.gy],[1,-2]);assert(B.perform(w,p,'build',data).ok);assert.equal(w.raft.length,10);assert.equal(p.inventory.plank,36);assert.equal(p.inventory.plastic,18);
 assert(!B.perform(w,p,'build',data).ok);assert.equal(p.inventory.plank,36);
 const remove=payload(w,p,'demolish',view);assert(B.perform(w,p,'demolish',remove).ok);assert.equal(w.raft.length,9);assert.deepEqual(w.resources.map(r=>[r.type,r.amount]),[['plank',2],['plastic',1]]);
 assert(w.resources.every(r=>r.persistent&&r.altitude===.44));assert(!B.perform(w,p,'demolish',remove).ok);assert.equal(w.resources.length,2);
 // Even if the same grid cell is rebuilt, an old tile ID cannot remove it.
 assert(B.perform(w,p,'build',payload(w,p,'build',view)).ok);assert(!B.perform(w,p,'demolish',remove).ok);assert.equal(w.raft.length,10);
});
test('destroyed support drops stations, and legacy counts migrate without loss or repetition',()=>{
 const w=world();w.stations={chest:11,purifier:1};B.ensure(w);assert.equal(w.structures.length,9);assert.equal(w.resources.length,3);assert.equal(w.stations.chest+w.stations.purifier,9);
 const total=w.structures.length+w.resources.length;B.ensure(w);assert.equal(w.structures.length+w.resources.length,total);
 const s=w.structures[0];w.raft=w.raft.filter(t=>t.gx!==s.gx||t.gy!==s.gy);assert.equal(B.removeUnsupported(w).length,1);assert.equal(w.structures.length,8);assert.equal(w.resources.length,4);const d=w.resources.at(-1);assert.equal(d.type,s.type);assert.equal(d.altitude,.44);assert(d.persistent);assert.equal(B.removeUnsupported(w).length,0);
});
test('zero-start first pickups fill empty slots; full material pickup does not discard held goods',()=>{
 const w=world(),p={inventory:{},tools:{},hotbar:Array(10).fill(null),selectedSlot:0,x:500,y:350,altitude:.52,motion:'RAFT_GROUNDED'};
 const r={id:'sea',type:'plank',x:500,y:330};w.resources.push(r);assert(I.collect(w,p,r));assert.equal(I.held(p),'plank');assert.equal(p.inventory.plank,2);
 const barrel={id:'barrel',type:'barrel',x:500,y:330};w.resources.push(barrel);assert(I.collect(w,p,barrel));assert(p.hotbar.includes('plastic'));assert(p.hotbar.includes('leaf'));assert(p.hotbar.includes('scrap'));
 p.hotbar=['hook','spear','axe','rod','plank','stone','food','water','plastic','scrap'];p.tools={hook:1,spear:1,axe:1,rod:1};Object.assign(p.inventory,{stone:1,food:1,water:1});p.selectedSlot=0;
 const leaf=I.spawnDrop(w,'leaf',12,500,350,.8);const n=w.resources.length;assert(I.collect(w,p,leaf));assert.equal(I.held(p),'hook');assert.equal(w.resources.length,n-1);assert.equal(p.inventory.leaf,14);
});
