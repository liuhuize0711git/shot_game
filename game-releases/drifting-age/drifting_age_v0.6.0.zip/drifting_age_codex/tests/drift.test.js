const test=require('node:test'),assert=require('node:assert/strict'),D=require('../public/drift');
test('ambient debris passes and expires, all player-created drops stay at their exact location',()=>{
 const w={resources:[{id:'flow',x:500,y:1049},{id:'saved',x:2700,y:1900,dropItem:true},{id:'crafted',x:430,y:300,dropTool:true},{id:'demolition',x:520,y:350,stationary:true,source:'demolition'}],nextResource:0};
 const saved=JSON.stringify(w.resources.slice(1));D.tick(w,1);assert.equal(w.resources.some(r=>r.id==='flow'),false);assert.equal(JSON.stringify(w.resources),saved);
});
test('persistent drops never block new current spawns; net catches an actual passing item',()=>{
 const w={resources:Array.from({length:80},(_,i)=>({id:'p'+i,x:0,y:0,dropItem:true})),structures:[{type:'net',x:500,y:350}]};
 D.tick(w,3);assert.equal(w.resources.length,81);w.resources.push({id:'catch',type:'plank',x:500,y:330});D.tick(w,1);const r=w.resources.find(r=>r.id==='catch');assert.equal(r.source,'net');assert.equal(r.amount,2);assert.equal(r.y,350);D.tick(w,1);assert.equal(r.y,350);
});
